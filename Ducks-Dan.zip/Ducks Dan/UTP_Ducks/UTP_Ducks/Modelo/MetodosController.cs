﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Windows.Forms;
using System.Data;
using UTP_Ducks.Controlador;
using System.Web.UI.WebControls;
using System.Data.OleDb;

namespace UTP_Ducks.Modelo
{
    // Recursos Humanos
    public class Persona
    {
        public int idPersona;
        public String RFC, Curp, Nombre, ApPaterno, ApMaterno, Genero, Estado_civil, Estatus;
        public DateTime FechaNacimiento;

        public Persona()
        {
            idPersona = 0;
            RFC = "";
            Curp = "";
            Nombre = "";
            ApPaterno = "";
            ApMaterno = "";
            Genero = "";
            Estado_civil = "";
            FechaNacimiento = DateTime.Now;
            Estatus = "";
        }
        public Persona(int ip, String r, String c, String n, String ap, String am, String g, String ec, DateTime fn, String e)
        {
            idPersona = ip;
            RFC = r;
            Curp = c;
            Nombre = n;
            ApPaterno = ap;
            ApMaterno = am;
            Genero = g;
            Estado_civil = ec;
            FechaNacimiento = fn;
            Estatus = e;
        }

        public int altaPersona()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Persona(RFC,Curp,Nombre,ApPaterno,ApMaterno,Genero,Estado_civil,FechaNacimiento,Estatus)" +
                    "values('" + RFC + "','" + Curp + "','" + Nombre + "','" + ApPaterno + "','" + ApMaterno + "','" + Genero + "','" + Estado_civil + "','" + FechaNacimiento.ToShortDateString() + "','" + Estatus + "')";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
        public int carga(ComboBox cmb)
        {
            Conexion selecciona = new Conexion();
            SqlDataReader lector;
            if (selecciona.conectar())
            {
                selecciona.construye_reader("select Nombre  from Persona");
                lector = selecciona.ejecuta_reader();
                while (lector.Read())
                    cmb.Items.Add(lector.GetString(0).ToString());
                selecciona.desconectar();
                selecciona.dr.Close();
                return 1;
            }
            else return -1;
        }
        public int cambioEstatus(String nom, string ap, string am)
        {
            SqlCommand Comando;
            Conexion actualiza = new Conexion();
            int regresa = 0;
            if (actualiza.conectar())
            {
                Comando = actualiza.construye_command("execute ELIMINACION '" + nom + "','" + ap + "','" + am + "'");
                if (actualiza.ejecutanonquery() != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                actualiza.desconectar();
            }
            else
                return -1;
            return regresa;
        }
        public void Consulta(GridView gv, String a, String ap, String am)
        {

            Conexion consulta = new Conexion();
            SqlDataReader lector;
            if (consulta.conectar())
            {
                consulta.construye_reader("EXECUTE CONSULTA_INFO_PERSONAL '" + a + "','" + ap + "','" + am + "'");
                lector = consulta.ejecuta_reader();
                gv.DataSource = lector;
                gv.DataBind();
                consulta.dr.Close();
                consulta.desconectar();
            }
        }
        public int regresaID()
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Top 1 (idPersona) from Persona Order By idPersona desc");
                    fila = selecciona.extrae_registro(adaptador, "Persona");
                    return Convert.ToInt32(fila["idPersona"]);
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra el Nombre");
                    return 0;
                }
            }
            else
                return -1;
        }
    }
    public class Telefono
    {
        public long Numero;
        public String Tipo;

        public Telefono()
        {
            Numero = 0;
            Tipo = "";
        }
        public Telefono(long n, String t)
        {
            Numero = n;
            Tipo = t;
        }
        public int altaTelefono()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Telefono(Numero,Tipo)" +
                    "values(" + Numero + ",'" + Tipo + "')";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
        public int altaTelefono2(long n, string t)
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Telefono(Numero,Tipo)" +
                    "values(" + n + ",'" + t + "')";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
        public int regresaID()
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Top 1 (idtelefono) from Telefono Order By idTelefono desc");
                    fila = selecciona.extrae_registro(adaptador, "Telefono");
                    return Convert.ToInt32(fila["idTelefono"]);
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra el Telefono");
                    return 0;
                }
            }
            else
                return -1;
        }
    }
    public class Contactos
    {
        public int idPersona, idTelefono;

        public Contactos()
        {
            idPersona = 0;
            idTelefono = 0;
        }
        public Contactos(int p, int t)
        {
            idPersona = p;
            idTelefono = t;
        }
        public int altaContactos()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Contactos(idPersona,idTelefono)" +
                    "values(" + idPersona + "," + idTelefono + ")";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
    }
    public class Direccion
    {
        public int idDireccion, NumExterior, CodigoPostal;
        public String NumInterior, Pais, Estado, Calle, Colonia, Tipo_domicilio;

        public Direccion()
        {
            idDireccion = 0;
            Pais = "";
            Estado = "";
            Calle = "";
            Colonia = "";
            NumInterior = "";
            NumExterior = 0;
            CodigoPostal = 0;
            Tipo_domicilio = "";
        }
        public Direccion(int i, String p, String e, String c, String cl, String ni, int ne, int cp, String td)
        {
            idDireccion = i;
            Pais = p;
            Estado = e;
            Calle = c;
            Colonia = cl;
            NumInterior = ni;
            NumExterior = ne;
            CodigoPostal = cp;
            Tipo_domicilio = td;
        }
        public int altaDireccion()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Direccion(Pais,Estado,Calle,Colonia,NumInterior,NumExterior,CodigoPostal,Tipo_domicilio)" +
                    "values('" + Pais + "','" + Estado + "','" + Calle + "','" + Colonia + "','" + NumInterior + "'," + NumExterior + "," + CodigoPostal + ",'" + Tipo_domicilio + "')";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
        public void Consulta(GridView gv, string a, string ap, string am)
        {

            Conexion consulta = new Conexion();
            SqlDataReader lector;
            if (consulta.conectar())
            {
                consulta.construye_reader("EXECUTE CONSULTA_DIR_PERSONA '" + a + "','" + ap + "','" + am + "'");
                lector = consulta.ejecuta_reader();
                gv.DataSource = lector;
                gv.DataBind();
                consulta.dr.Close();
                consulta.desconectar();
            }
        }
        public int regresaID()
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Top 1 (idDireccion) from Direccion Order By idDireccion desc");
                    fila = selecciona.extrae_registro(adaptador, "Direccion");
                    return Convert.ToInt32(fila["idDireccion"]);
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra la direccion ");
                    return 0;
                }
            }
            else
                return -1;
        }

    }
    public class Requiere_de
    {
        public int idPersona, idDireccion;

        public Requiere_de()
        {
            idPersona = 0;
            idDireccion = 0;
        }
        public Requiere_de(int p, int d)
        {
            idPersona = p;
            idDireccion = d;
        }
        public int altaRequiere_de()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Requiere_de(idPersona,idDireccion)" +
                    "values(" + idPersona + "," + idDireccion + ")";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }

    }
    public class Candidatos
    {
        public int idPersona;
        public long No_IMSS;
        public String Email;

        public Candidatos()
        {
            idPersona = 0;
            Email = "";
            No_IMSS = 0;
        }
        public Candidatos(int i, String e, long n)
        {
            idPersona = i;
            Email = e;
            No_IMSS = n;
        }
        public int alta()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Candidatos(idPersona,Email,No_IMSS)" +
                    "values(" + idPersona + ",'" + Email + "'," + No_IMSS + ")";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
        public int regresaID()
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Top 1 (idPersona) from Persona Order By idPersona desc");
                    fila = selecciona.extrae_registro(adaptador, "Persona");
                    return Convert.ToInt32(fila["idPersona"]);
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra el Nombre");
                    return 0;
                }
            }
            else
                return -1;
        }
    }
    public class Estudios
    {
        public int idCandidato;
        public String Nivel_Estudios, Pais, Institucion, Area, Titulo;
        public DateTime Fecha_Inicio, Fecha_Terminos;
        public Double Promedio;

        public Estudios()
        {
            idCandidato = 0;
            Nivel_Estudios = "";
            Pais = "";
            Institucion = "";
            Area = "";
            Titulo = "";
            Fecha_Inicio = DateTime.Now;
            Fecha_Terminos = DateTime.Now;
            Promedio = 0.0;
        }
        public Estudios(int i, string n, string p, string ins, string a, string t, DateTime fi, DateTime ft, Double pp)
        {
            idCandidato = i;
            Nivel_Estudios = n;
            Pais = p;
            Institucion = ins;
            Area = a;
            Titulo = t;
            Fecha_Inicio = fi;
            Fecha_Terminos = ft;
            Promedio = pp;
        }
        public int alta()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Estudios(idCandidatos,Nivel_Estudios,Pais,Institucion,Area,Titulo,Fecha_Inicio,Fecha_Terminos,Promedio)" +
                    "values(" + idCandidato + ",'" + Nivel_Estudios + "','" + Pais + "','" + Institucion + "','" + Area + "','" + Titulo + "','" + Fecha_Inicio.ToShortDateString() + "','" + Fecha_Terminos.ToShortDateString() + "'," + Promedio + ")";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
        public int regresaID()
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Top 1 (idCandidatos) from Candidatos Order By idCandidatos desc");
                    fila = selecciona.extrae_registro(adaptador, "Candidatos");
                    return Convert.ToInt32(fila["idCandidatos"]);
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra el Candidato");
                    return 0;
                }
            }
            else
                return -1;
        }
        public void Consulta(GridView gv, string a, string ap, string am)
        {

            Conexion consulta = new Conexion();
            SqlDataReader lector;
            if (consulta.conectar())
            {
                consulta.construye_reader("EXECUTE CONSULTA_FORMACION_ESTUDIOS '" + a + "','" + ap + "','" + am + "'");
                lector = consulta.ejecuta_reader();
                gv.DataSource = lector;
                gv.DataBind();
                consulta.dr.Close();
                consulta.desconectar();
            }
        }
    }
    public class PreferenciasLaborales
    {
        public int idCandidatos;
        public String Turno, Area, Puesto, Objetivo, Extra;
        public Double Sueldo;
        public PreferenciasLaborales()
        {
            idCandidatos = 0;
            Turno = "";
            Area = "";
            Puesto = "";
            Sueldo = 0.0;
            Objetivo = "";
            Extra = "";
        }
        public PreferenciasLaborales(int i, string t, string a, string p, double s, string o, string e)
        {
            idCandidatos = i;
            Turno = t;
            Area = a;
            Puesto = p;
            Sueldo = s;
            Objetivo = o;
            Extra = e;
        }
        public int alta()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Referencias(idCandidatos,turno,Area,Puesto,Sueldo,Objetivo,Extra)" +
                    "values(" + idCandidatos + ",'" + Turno + "','" + Area + "','" + Puesto + "'," + Sueldo + ",'" + Objetivo + "','" + Extra + "')";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
        public int regresaID()
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Top 1 (idCandidatos) from Candidatos Order By idCandidatos desc");
                    fila = selecciona.extrae_registro(adaptador, "Candidatos");
                    return Convert.ToInt32(fila["idCandidatos"]);
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra el Candidato");
                    return 0;
                }
            }
            else
                return -1;
        }


    }
    public class Referencias
    {
        public int idCandidato;
        public long TelefonoReferen;
        public String NombreReferen, DireccionReferen, OcupacionReferen;

        public Referencias()
        {
            idCandidato = 0;
            NombreReferen = "";
            DireccionReferen = "";
            OcupacionReferen = "";
            TelefonoReferen = 0;
        }
        public Referencias(int i, string n, string d, string o, long t)
        {
            idCandidato = i;
            NombreReferen = n;
            DireccionReferen = d;
            OcupacionReferen = o;
            TelefonoReferen = t;
        }
        public int alta()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Referencias(idCandidatos,NombreReferen,DireccionReferen,OcupacionReferen,TelefonoReferen)" +
                    "values(" + idCandidato + ",'" + NombreReferen + "','" + DireccionReferen + "','" + OcupacionReferen + "'," + TelefonoReferen + ")";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
        public int regresaID()
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Top 1 (idCandidatos) from Candidatos Order By idCandidatos desc");
                    fila = selecciona.extrae_registro(adaptador, "Candidatos");
                    return Convert.ToInt32(fila["idCandidatos"]);
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra el Candidato");
                    return 0;
                }
            }
            else
                return -1;
        }


    }
    public class Idiomas
    {
        public int idCandidatos;
        public String Nombre, Descripcion, nivel;

        public Idiomas()
        {
            idCandidatos = 0;
            Nombre = "";
            nivel = "";
            Descripcion = "";
        }
        public Idiomas(int i, String n, string lvl, string d)
        {
            idCandidatos = i;
            Nombre = n;
            nivel = lvl;
            Descripcion = d;
        }
        public int alta()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Idioma(idCandidatos,Nombre,nivel,Descripcion)" +
                    "values(" + idCandidatos + ",'" + Nombre + "','" + nivel + "','" + Descripcion + "')";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
        public int regresaID()
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Top 1 (idCandidatos) from Candidatos Order By idCandidatos desc");
                    fila = selecciona.extrae_registro(adaptador, "Candidatos");
                    return Convert.ToInt32(fila["idCandidatos"]);
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra el Candidato");
                    return 0;
                }
            }
            else
                return -1;
        }

    }
    public class MasInformacion
    {
        public int idCandidatos;
        public String Herramientas_Oficina, Herra_Info, Cursos, ConocimientosTecn, ConocimientosFinanci;

        public MasInformacion()
        {
            idCandidatos = 0;
            Herramientas_Oficina = "";
            Herra_Info = "";
            Cursos = "";
            ConocimientosTecn = "";
            ConocimientosFinanci = "";
        }
        public MasInformacion(int i, string ho, string hi, string c, string ct, string cf)
        {
            idCandidatos = i;
            Herramientas_Oficina = ho;
            Herra_Info = hi;
            Cursos = c;
            ConocimientosTecn = ct;
            ConocimientosFinanci = cf;
        }
        public int alta()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Mas_Informacion(idCandidatos,Herramientas_Oficina,Herra_Info,Cursos,ConocimientosTecn,ConocimientosFinanci)" +
                    "values(" + idCandidatos + ",'" + Herramientas_Oficina + "','" + Herra_Info + "','" + Cursos + "','" + ConocimientosTecn + "','" + ConocimientosFinanci + "')";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
        public int regresaID()
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Top 1 (idCandidatos) from Candidatos Order By idCandidatos desc");
                    fila = selecciona.extrae_registro(adaptador, "Candidatos");
                    return Convert.ToInt32(fila["idCandidatos"]);
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra el Candidato");
                    return 0;
                }
            }
            else
                return -1;
        }

    }
    public class Test
    {
        public int idUsuario, HS, CDRH, CEPI, HERI, SCTRI;
        public String PersonalidadEmpuje, PersonalidadOficina, Departamento;

        public Test()
        {
            idUsuario = 0;
            HS = 0;
            CDRH = 0;
            CEPI = 0;
            HERI = 0;
            SCTRI = 0;
            PersonalidadEmpuje = "";
            PersonalidadOficina = "";
            Departamento = "";
        }
        public Test(int i,int h,int c,int ce,int he,int s,string pe,string po,string d)
        {
            idUsuario = i;
            HS = h;
            CDRH = c;
            CEPI = ce;
            HERI = he;
            SCTRI = s;
            PersonalidadEmpuje = pe;
            PersonalidadOficina = po;
            Departamento = d;
        }
        public int alta()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Test(idUsuario,HS,CDRH,CEPI,HERI,SCTRI,PersonalidadEmpuje,PersonalidadOficina,Departamento)" +
                    "values(" + idUsuario + "," + HS + ","+CDRH+","+CEPI+","+HERI+","+SCTRI+",'"+PersonalidadEmpuje+"','"+PersonalidadOficina+"','"+Departamento+"')";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
        public int personalidad(int u)
        {
            SqlCommand Comando;
            Conexion actualiza = new Conexion();
            int regresa = 0;
            if (actualiza.conectar())
            {
                Comando = actualiza.construye_command("UPDATE Test set PersonalidadEmpuje= '" + PersonalidadEmpuje + "'"+
                    ",PersonalidadOficina= '" + PersonalidadOficina + "'  where idUsuario=" + u + "");
                if (actualiza.ejecutanonquery() != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                actualiza.desconectar();
            }
            else
                return -1;
            return regresa;
        }
        public int regresaIDU()
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Top 1 (idUsuario) from Usuario Order By idUsuario desc");
                    fila = selecciona.extrae_registro(adaptador, "Usuario");
                    return Convert.ToInt32(fila["idUsuario"]);
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra al usuario");
                    return 0;
                }
            }
            else
                return -1;
        }
    }
    public class HistorialLaboral
    {
        public int idCandidatos, Contacto;
        public long Telefono_Jefe;
        public String Empresa, Area, Puesto, Industri, Motivo_Salida, Jefe_Imediato, Puesto_Jefe, Comentarios;
        public DateTime Fecha_Inicio, Fecha_Fin;
        public Double Sueldo;

        public HistorialLaboral()
        {
            idCandidatos = 0;
            Empresa = "";
            Fecha_Inicio = DateTime.Now;
            Fecha_Fin = DateTime.Now;
            Area = "";
            Puesto = "";
            Industri = "";
            Sueldo = 0.0;
            Motivo_Salida = "";
            Jefe_Imediato = "";
            Puesto_Jefe = "";
            Telefono_Jefe = 0;
            Contacto = 0;
            Comentarios = "";

        }
        public HistorialLaboral(int i, string e, DateTime fi, DateTime ff, string a, string p, string ind, Double s, string m, string j, string pj, long t, int c, string com)
        {
            idCandidatos = i;
            Empresa = e;
            Fecha_Inicio = fi;
            Fecha_Fin = ff;
            Area = a;
            Puesto = p;
            Industri = ind;
            Sueldo = s;
            Motivo_Salida = m;
            Jefe_Imediato = j;
            Puesto_Jefe = pj;
            Telefono_Jefe = t;
            Contacto = c;
            Comentarios = com;

        }
        public int alta()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Hiistorial_Laboral(idCandidatos,Empresa,Fecha_Inicio,Fecha_Fin,Area,Puesto,Industri,Sueldo,Motivo_Salida,Jefe_Imediato,Puesto_Jefe,Telefono_Jefe,Contacto,Comentarios)" +
                    "values(" + idCandidatos + ",'" + Empresa + "','" + Fecha_Inicio.ToShortDateString() + "','" + Fecha_Fin.ToShortDateString() + "','" + Area + "','" + Puesto + "','" + Industri + "'," + Sueldo + ",'" + Motivo_Salida + "','" + Jefe_Imediato + "','" + Puesto_Jefe + "'," + Telefono_Jefe + "," + Contacto + ",'" + Comentarios + "')";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
        public int regresaID()
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Top 1 (idCandidatos) from Candidatos Order By idCandidatos desc");
                    fila = selecciona.extrae_registro(adaptador, "Candidatos");
                    return Convert.ToInt32(fila["idCandidatos"]);
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra el Candidato");
                    return 0;
                }
            }
            else
                return -1;
        }
        public void Consulta(GridView gv, string a, string ap, string am)
        {

            Conexion consulta = new Conexion();
            SqlDataReader lector;
            if (consulta.conectar())
            {
                consulta.construye_reader("EXECUTE CONSULTA_HISTORIAL_LABORAL '" + a + "','" + ap + "','" + am + "'");
                lector = consulta.ejecuta_reader();
                gv.DataSource = lector;
                gv.DataBind();
                consulta.dr.Close();
                consulta.desconectar();
            }
        }
    }
    public class Empleado
    {
        public int idPersona;
        public String Area, Puesto;
        public String foto;

        public Empleado()
        {
            idPersona = 0;
            Area = "";
            Puesto = "";
            foto = "";
        }
        public Empleado(int i, String a, String p, string f)
        {
            idPersona = i;
            Area = a;
            Puesto = p;
            foto = f;
        }
        public int alta()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Empleado(idPersona,Area,Puesto,Foto)" +
                    "values(" + idPersona + ",'" + Area + "','" + Puesto + "','" + foto + "')";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
        public int regresaID()
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Top 1 (idPersona) from Persona Order By idPersona desc");
                    fila = selecciona.extrae_registro(adaptador, "Persona");
                    return Convert.ToInt32(fila["idPersona"]);
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra el Nombre");
                    return 0;
                }
            }
            else
                return -1;
        }
        public int regresaID2()
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Top 1 (idEmpleado) from Empleado Order by idEmpleado desc");
                    fila = selecciona.extrae_registro(adaptador, "Empleado");
                    return Convert.ToInt32(fila["idEmpleado"]);
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra al Empleado");
                    return 0;
                }
            }
            else
                return -1;
        }


    }
    public class Usuario
    {
        public int idPersona;
        public String Tipo_Usuario, Password_2;

        public Usuario()
        {
            idPersona = 0;
            Tipo_Usuario = "";
            Password_2 = "";
        }

        public Usuario(int i, string t, string p)
        {
            idPersona = i;
            Tipo_Usuario = t;
            Password_2 = p;
        }

        public int altaUsuario()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Usuario(idPersona, CorreoInicio, Password1)" +
                    "values(" + idPersona + ",'" + Tipo_Usuario + "','" + Password_2 + "')";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
        public int regresaID()
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Top 1 (idPersona) from Persona Order By idPersona desc");
                    fila = selecciona.extrae_registro(adaptador, "Persona");
                    return Convert.ToInt32(fila["idPersona"]);
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra la Persona ");
                    return 0;
                }
            }
            else
                return -1;
        }
        public int cambiocontraseña(String newC, string AC, string usu)
        {
            SqlCommand Comando;
            Conexion actualiza = new Conexion();
            int regresa = 0;
            if (actualiza.conectar())
            {
                Comando = actualiza.construye_command("execute CAMBIO_CONTRASEÑA '" + AC + "','" + newC + "','" + usu + "'");
                if (actualiza.ejecutanonquery() != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                actualiza.desconectar();
            }
            else
                return -1;
            return regresa;
        }
        public String regresaT(string n, string ap, string am)
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter(" select CorreoInicio" +
                            "from Usuario u inner join Persona p on u.idPersona=p.idPersona" +
                                "where Nombre='" + n + "' and ApPaterno ='" + ap + "' and ApMaterno='" + am + "'");
                    fila = selecciona.extrae_registro(adaptador, "Usuario");
                    return fila["CorreoInicio"].ToString();
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra al usuario");
                    return "";
                }
            }
            else
                return "";
        }
        public int regresaID1(string n)
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select idPersona from Usuario where CorreoInicio='" + n + "'");
                    fila = selecciona.extrae_registro(adaptador, "Persona");
                    return Convert.ToInt32(fila["idPersona"]);
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra al usuario");
                    return 0;
                }
            }
            else
                return -1;
        }
        public String regresaIDN(int n)
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Nombre from Persona p inner join Usuario u on u.idPersona=p.idPersona where idPersona=" + n + "");
                    fila = selecciona.extrae_registro(adaptador, "Persona");
                    return fila["Nombre"].ToString();
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra al usuario");
                    return "";
                }
            }
            else
                return "";
        }
        public String regresaIDAP(int n)
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select ApPaterno from Persona p inner join Usuario u on u.idPersona=p.idPersona where idPersona=" + n + "");
                    fila = selecciona.extrae_registro(adaptador, "Persona");
                    return fila["ApPaterno"].ToString();
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra al usuario");
                    return "";
                }
            }
            else
                return "";
        }
        public String regresaIDAM(int n)
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select ApMaterno from Usuario e inner join Persona p on e.idPersona=p.idPersona where idUsuario=" + n + "");
                    fila = selecciona.extrae_registro(adaptador, "Persona");
                    return fila["ApMaterno"].ToString();
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra al usuario");
                    return "";
                }
            }
            else
                return "";
        }
        public String regresaG(int n)
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Genero from Usuario e inner join Persona p on e.idPersona=p.idPersona where idUsuario=" + n + "");
                    fila = selecciona.extrae_registro(adaptador, "Persona");
                    return fila["Genero"].ToString();
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra al usuario");
                    return "";
                }
            }
            else
                return "";
        }
        public String regresaC(int n)
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Curp from Usuario e inner join Persona p on e.idPersona=p.idPersona where idUsuario=" + n + "");
                    fila = selecciona.extrae_registro(adaptador, "Persona");
                    return fila["Curp"].ToString();
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra al usuario");
                    return "";
                }
            }
            else
                return "";
        }
        public String regresaRFC(int n)
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select RFC from Usuario e inner join Persona p on e.idPersona=p.idPersona where idUsuario=" + n + "");
                    fila = selecciona.extrae_registro(adaptador, "Persona");
                    return fila["RFC"].ToString();
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra al usuario");
                    return "";
                }
            }
            else
                return "";
        }
        public String regresaEC(int n)
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Estado_Civil from Usuario e inner join Persona p on e.idPersona=p.idPersona where idUsuario=" + n + "");
                    fila = selecciona.extrae_registro(adaptador, "Persona");
                    return fila["Estado_civil"].ToString();
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra al usuario");
                    return "";
                }
            }
            else
                return "";
        }
        public String regresaFN(int n)
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select FechaNacimiento from Usuario e inner join Persona p on e.idPersona=p.idPersona where idUsuario=" + n + "");
                    fila = selecciona.extrae_registro(adaptador, "Persona");
                    return fila["FechaNacimiento"].ToString();
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra al usuario");
                    return "";
                }
            }
            else
                return "";
        }
    }
    public class Privilegios
    {
        public int statusPrivilegio;
        public String TipoPrivilegio;

    }
    public class Proporcionan
    {
        public int idUsuario, idPrivilegio;
        public int altaRequiere_de()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Proporcionan(idUsuario,idPrivilegio)" +
                    "values(" + idUsuario + "," + idPrivilegio + ")";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }

    }
    public class Academico
    {
        public int idEmpleado;
        public String TituloObtenido, Institucion;
        public DateTime Inicio, Fin;

        public Academico()
        {
            idEmpleado = 0;
            TituloObtenido = "";
            Inicio = DateTime.Now;
            Fin = DateTime.Now;
            Institucion = "";
        }
        public Academico(int i, string t, DateTime ini, DateTime f, string ins)
        {
            idEmpleado = i;
            TituloObtenido = t;
            Inicio = ini;
            Fin = f;
            Institucion = ins;
        }
        public int alta()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Academico(idEmpleado,TituloObtenido,Inicio,Fin,Institucion)" +
                    "values(" + idEmpleado + ",'" + TituloObtenido + "','" + Inicio.ToShortDateString() + "','" + Fin.ToShortDateString() + "','" + Institucion + "')";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
        public int regresaID()
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Top 1 (idEmpleado) from Empleado Order By idEmpleado desc");
                    fila = selecciona.extrae_registro(adaptador, "Empleado");
                    return Convert.ToInt32(fila["idEmpleado"]);
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra el Empleado");
                    return 0;
                }
            }
            else
                return -1;
        }

    }
    public class Habilidad
    {
        public int idEmpleado;
        public String Descripcion, Tipo;

        public Habilidad()
        {
            idEmpleado = 0;
            Descripcion = "";
            Tipo = "";
        }
        public Habilidad(int i, string d, string t)
        {
            idEmpleado = i;
            Descripcion = d;
            Tipo = t;
        }
        public int alta()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Habilidad(idEmpleado,Descripcion,Tipo)" +
                    "values(" + idEmpleado + ",'" + Descripcion + "','" + Tipo + "')";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
        public int regresaID()
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Top 1 (idEmpleado) from Empleado Order By idEmpleado desc");
                    fila = selecciona.extrae_registro(adaptador, "Empleado");
                    return Convert.ToInt32(fila["idEmpleado"]);
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra el Empleado");
                    return 0;
                }
            }
            else
                return -1;
        }
    }
    public class Jornada
    {
        public String Turno, Tipo, Dia_Semana;
        public String HoraEntrada, HoraSalida;

        public Jornada()
        {
            Turno = "";
            Tipo = "";
            Dia_Semana = "";
            HoraEntrada = "";
            HoraSalida = "";
        }
        public Jornada(string t, string ti, string d, String he, String hs)
        {
            Turno = t;
            Tipo = ti;
            Dia_Semana = d;
            HoraEntrada = he;
            HoraSalida = hs;
        }
        public int alta()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Jornada(Turno,Tipo,dia_Semana,HoraEntrada,HoraSalida)" +
                    "values('" + Turno + "','" + Tipo + "','" + Dia_Semana + "','" + HoraEntrada + "','" + HoraSalida + "')";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
        public int regresaID()
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Top 1 (idjornada) from Jornada Order By idJornada desc");
                    fila = selecciona.extrae_registro(adaptador, "Jornada");
                    return Convert.ToInt32(fila["idJornada"]);
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra la direccion ");
                    return 0;
                }
            }
            else
                return -1;
        }
    }
    public class Asiste
    {
        public int idJornada, idEmpleado;

        public Asiste()
        {
            idEmpleado = 0;
            idJornada = 0;
        }
        public Asiste(int ie, int ij)
        {
            idEmpleado = ie;
            idJornada = ij;
        }

        public int alta()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Asiste(idEmpleado,idJornada)" +
                    "values(" + idEmpleado + "," + idJornada + ")";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
    }
    public class Area
    {
        public int idEmpleado;
        public long Telefono;
        public String Aarea, Descripcion, Caracteristicas;

        public Area()
        {
            idEmpleado = 0;
            Telefono = 0;
            Aarea = "";
            Descripcion = "";
            Caracteristicas = "";
        }
        public Area(int i, long t, string a, string d, string c)
        {
            idEmpleado = 0;
            Telefono = 0;
            Aarea = "";
            Descripcion = "";
            Caracteristicas = "";
        }
        public int alta()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Area(idEmpleado,Telefono,Area,Descripcion,Caracteristicas)" +
                    "values(" + idEmpleado + "," + Telefono + ",'" + Aarea + "','" + Descripcion + "','" + Caracteristicas + "')";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
        public int regresaID()
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Top 1 (idEmpleado) from Empleado Order By idEmpleado desc");
                    fila = selecciona.extrae_registro(adaptador, "Empleado");
                    return Convert.ToInt32(fila["idEmpleado"]);
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra el Empleado");
                    return 0;
                }
            }
            else
                return -1;
        }
    }


    // Recursos Materiales


    public class Proveedor
    {
        public int idProveedor;
        public String Nombre_RazonSocial, Email;

        public Proveedor()
        {
            idProveedor = 0;
            Nombre_RazonSocial = "";
            Email = "";
        }

        public Proveedor(int i, string n, string e)
        {
            idProveedor = i;
            Nombre_RazonSocial = n;
            Email = e;
        }

        public int altaProveedor()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Proveedor(Nombre_RazonSocial, Email)" +
                    "values('" + Nombre_RazonSocial + "','" + Email + "')";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
        public int regresaID()
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Top 1 (idProveedor) from Proveedor Order By idProveedor desc");
                    fila = selecciona.extrae_registro(adaptador, "Proveedor");
                    return Convert.ToInt32(fila["idProveedor"]);
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra el proveedor");
                    return 0;
                }
            }
            else
                return -1;
        }
    }
    public class TelefonoProveedor
    {
        public int idProveedor, Numero;
        public String Tipo;

        public TelefonoProveedor()
        {
            idProveedor = 0;
        }

        public TelefonoProveedor(int i)
        {
            idProveedor = i;
        }
        public int altaTelefonoProveedor()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into ProveedorTelefono(Numero,Tipo)" +
                    "values(" + Numero + ",'" + Tipo + "')";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }

    }
    public class Entradas
    {
        public int idEmpleado;
        public string Descripcion;
        public double Total;
        public String Hora;
        public DateTime Fecha;

        public Entradas()
        {
            idEmpleado = 0;
            Descripcion = "";
            Total = 0;
            Hora = "";
            Fecha = DateTime.Now;
        }

        public Entradas(int e, string d, double t, String h, DateTime f)
        {
            idEmpleado = e;

            Descripcion = d;
            Total = t;
            Hora = h;
            Fecha = f;
        }

        public int altaEntrada()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Entradas(idEmpleado, Descripcion, Total, Fecha, Hora)" +
                    "values('" + idEmpleado + "','" + Descripcion + "','" + Total + "','" + Fecha.ToShortDateString() + "','" + Hora + "')";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }

        public int regresaID(String nom)
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select idEmpleado from Persona INNER JOIN Empleado on Persona.idPersona=Empleado.idPersona where Nombre ='" + nom + "'");
                    fila = selecciona.extrae_registro(adaptador, "Empleado");
                    return Convert.ToInt32(fila["idEmpleado"]);
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra el Nombre");
                    return 0;
                }
            }
            else
                return -1;
        }

        public int regresaID()
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Top 1 (idEntrada) from Entradas Order By idEntradas desc");
                    fila = selecciona.extrae_registro(adaptador, "Entradas");
                    return Convert.ToInt32(fila["idEntrada"]);
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra el proveedor");
                    return 0;
                }
            }
            else
                return -1;
        }


    }
    public class Productos
    {
        public string Modelo, Marca, Descripcion, Grupo, UnidadMedida;
        public DateTime Fecha;
        public double CantidadMedida, PrecioCompra;
        public int Stock;

        public Productos()
        {
            Modelo = "";
            Marca = "";
            Descripcion = "";
            Fecha = DateTime.Now;
            Grupo = "";
            UnidadMedida = "";
            CantidadMedida = 0;
            PrecioCompra = 0;
            Stock = 0;
        }

        public Productos(string m, string ma, string d, string g, DateTime f, string u, double c, double p, int s)
        {
            Modelo = m;
            Marca = ma;
            Descripcion = d;
            Grupo = g;
            Fecha = f;
            UnidadMedida = u;
            CantidadMedida = c;
            PrecioCompra = p;
            Stock = s;
        }

        public int altaProducto()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Producto(Modelo,Marca, Descripcion, Fecha, Grupo, UnidadMedida, CantidadMedida, PrecioCompra,Stock)" +
                    "values('" + Modelo + "','" + Marca + "','" + Descripcion + "','" + Fecha.ToShortDateString() + "','" + Grupo + "','" + UnidadMedida + "','" + CantidadMedida + "'," + PrecioCompra + "," + Stock + " )";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
        public int regresaID()
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Top 1 (idProducto) from idProducto Order By idProducto desc");
                    fila = selecciona.extrae_registro(adaptador, "Producto");
                    return Convert.ToInt32(fila["idProducto"]);
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra el Nombre");
                    return 0;
                }
            }
            else
                return -1;
        }

        public int regresaID(String nom)
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select idProducto from Producto where Marca='" + nom + "'");
                    fila = selecciona.extrae_registro(adaptador, "Producto");
                    return Convert.ToInt32(fila["idProducto"]);
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra el Nombre");
                    return 0;
                }
            }
            else
            {

            }
            return -1;
        }
        public int carga(DropDownList cmb)
        {
            Conexion selecciona = new Conexion();
            SqlDataReader lector;
            if (selecciona.conectar())
            {
                selecciona.construye_reader("select Grupo from Producto");
                lector = selecciona.ejecuta_reader();
                while (lector.Read())
                    cmb.Items.Add(lector.GetString(0).ToString());
                selecciona.desconectar();
                selecciona.dr.Close();
                return 1;
            }
            else return -1;
        }
    }
    public class Detalle_Producto
    {
        public int id_Compra, idProducto, Cantidad;
        public double Precio_Venta;

        public Detalle_Producto()
        {
            id_Compra = 0;
            idProducto = 0;
            Cantidad = 0;
            Precio_Venta = 0;
        }

        public Detalle_Producto(int ic, int ip, int c, double pv)
        {
            id_Compra = ic;
            idProducto = ip;
            Cantidad = c;
            Precio_Venta = pv;
        }

        public int altaDetalle_Producto()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Detalle_Producto(id_Compra,idProducto, Cantidad, Precio_Venta)" +
                    "values(" + id_Compra + "," + idProducto + "," + Cantidad + "," + Precio_Venta + ")";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }

    }
    public class Salida
    {
        public int idEmpleado;
        public String Descripcion, Hora;
        public DateTime Fecha;

        public Salida()
        {
            idEmpleado = 0;
            Descripcion = "";
            Hora = "";
            Fecha = DateTime.Now;
        }

        public Salida(int i, string d, string h, DateTime f)
        {
            idEmpleado = i;
            Descripcion = d;
            Hora = h;
            Fecha = f;
        }

        public int altaSalida()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Salida(idEmpleado,Descripcion, Hora, Fecha)" +
                    "values(" + idEmpleado + ",'" + Descripcion + "','" + Hora + "','" + Fecha.ToShortDateString() + "')";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }

        public int regresaID()
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Top 1 (idServicios) from Servicios Order By idServicios desc");
                    fila = selecciona.extrae_registro(adaptador, "Servicios");
                    return Convert.ToInt32(fila["idServicios"]);
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra la direccion ");
                    return 0;
                }
            }
            else
                return -1;
        }



    }
    public class Cuenta
    {
        public int idProveedor, idDireccion;

        public Cuenta()
        {
            idDireccion = 0;
            idProveedor = 0;
        }
        public int alta()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Cuenta(idProveedor,idDireccion)" +
                    "values(" + idProveedor + "," + idDireccion + ")";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
    }
    public class DetalleEntrada
    {
        public int idEntrada, idProducto, No_Articulos;
        public DetalleEntrada()
        {
            idEntrada = 0;
            idProducto = 0;
            No_Articulos = 0;
        }
        public int altaDetalleEntrada()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into DetalleEntrada(idEntrada,idProducto,No_Articulos)" +
                    "values(" + idEntrada + "," + idProducto + "," + No_Articulos + ")";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
        public void Consulta(GridView gv, DateTime fi, DateTime ff)
        {

            Conexion consulta = new Conexion();
            SqlDataReader lector;
            if (consulta.conectar())
            {
                consulta.construye_reader("execute CONSULTA_ENTRADAS '" + fi.ToShortDateString() + "' ,'" + ff.ToShortDateString() + "'");
                lector = consulta.ejecuta_reader();
                gv.DataSource = lector;
                gv.DataBind();
                consulta.dr.Close();
                consulta.desconectar();
            }
        }
    }
    public class DetalleSalida
    {
        public int idSalida, idProducto, No_Articulos;

        public DetalleSalida()
        {
            idSalida = 0;
            idProducto = 0;
            No_Articulos = 0;
        }
        public int alta()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Cuenta(idSalida,idProducto,No_Articulos)" +
                    "values(" + idSalida + "," + idProducto + "," + No_Articulos + ")";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
        public void Consulta(GridView gv, DateTime fi, DateTime ff)
        {

            Conexion consulta = new Conexion();
            SqlDataReader lector;
            if (consulta.conectar())
            {
                consulta.construye_reader("execute CONSULTA_SALIDAS '" + fi.ToShortDateString() + "' ,'" + ff.ToShortDateString() + "'");
                lector = consulta.ejecuta_reader();
                gv.DataSource = lector;
                gv.DataBind();
                consulta.dr.Close();
                consulta.desconectar();
            }
        }
    }


    // Recursos Financieros 


    public class Servicios
    {
        public double Precio;
        public int Identificador;
        public string Nombre, Descripcion;

        public Servicios()
        {
            Precio = 0;
            Nombre = "";
            Identificador = 0;
            Descripcion = "";
        }

        public Servicios(double p, string n, int i, string d)
        {
            Precio = p;
            Nombre = n;
            Identificador = i;
            Descripcion = d;
        }

        public int altaServicios()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Servicios(Precio,Nombre,Identificador,Descripcion)" +
                    "values(" + Precio + ",'" + Nombre + "'," + Identificador + ",'" + Descripcion + "')";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
        public int regresaID(String nom)
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select idProveedor from Proveedor where Nombre_RazonSocial='" + nom + "'");
                    fila = selecciona.extrae_registro(adaptador, "Proveedor");
                    return Convert.ToInt32(fila["idProveedor"]);
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra el Nombre");
                    return 0;
                }
            }
            else
            {

            }
            return -1;
        }
        public int regresaID()
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Top 1 (idServicios) from Servicios Order By idServicios desc");
                    fila = selecciona.extrae_registro(adaptador, "Servicios");
                    return Convert.ToInt32(fila["idServicios"]);
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra la direccion ");
                    return 0;
                }
            }
            else
                return -1;
        }
    }
    public class Atiende
    {
        public int idServicios, idProveedor;

        public Atiende()
        {
            idServicios = 0;
            idProveedor = 0;
        }

        public Atiende(int s, int p)
        {
            idServicios = s;
            idProveedor = p;
        }

        public int altaAtiende()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Atiende(idServicios,idProveedor)" +
                    "values(" + idServicios + "," + idProveedor + ")";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }
    }
    public class Solicitud
    {
        public DateTime Fecha;
        public double Monto, idUsuario;
        public string Caracteristicas, Tipo, Status_2;

        public Solicitud()
        {
            Fecha = DateTime.Now;
            Monto = 0;
            Caracteristicas = "";
            Tipo = "";
            Status_2 = "";
        }

        public Solicitud(double m, string c, string t, string s, DateTime f)
        {
            Fecha = f;
            Monto = m;
            Caracteristicas = c;
            Tipo = t;
            Status_2 = s;
        }

        public int altaSolicitud()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Solicitud_Compra(idUsuario,Caracteristicas,Tipo,Fecha,Monto,Status_2)" +
                    "values('" + idUsuario + "','" + Caracteristicas + "','" + Tipo + "','" + Fecha.ToShortDateString() + "'," + Monto + ",'" + Status_2 + "')";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }

        public int regresaID3(String nom)
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select idUsuario FROM Usuario U INNER  JOIN Persona P ON U.idPersona=P.idPersona WHERE Nombre='" + nom + "'");
                    fila = selecciona.extrae_registro(adaptador, "Usuario");
                    return Convert.ToInt32(fila["idUsuario"]);
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra el Nombre");
                    return 0;
                }
            }
            else
                return -1;
        }


        public string regresaNombre(string n)
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Descripcion from Producto where Descripcion ='" + n + "' ");
                    fila = selecciona.extrae_registro(adaptador, "Producto");
                    return Convert.ToString(fila["Descripcion"]);
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra el Producto");
                    return null;
                }
            }
            else
                return "";

        }

        public int regresaID()
        {
            Conexion selecciona = new Conexion();
            SqlDataAdapter adaptador;
            DataRow fila;
            if (selecciona.conectar())
            {
                try
                {
                    adaptador = selecciona.construye_adapter("select Top 1 (idCompra) from Solicitud_Compra Order By idCompra desc");
                    fila = selecciona.extrae_registro(adaptador, "Solicitud_Compra");
                    return Convert.ToInt32(fila["idCompra"]);
                }
                catch (Exception)
                {
                    MessageBox.Show("No se encuentra el Nombre");
                    return 0;
                }
            }
            else
                return -1;
        }
    }
    public class Detalles_Servicios
    {
        public int id_Compra, idServicios;

        public Detalles_Servicios()
        {
            id_Compra = 0;
            idServicios = 0;
        }
        public Detalles_Servicios(int ic, int i)
        {
            id_Compra = ic;
            idServicios = i;
        }

        public int altaDetalles_Servicios()
        {
            SqlCommand Comando;
            Conexion inserta = new Conexion();
            int regresa = 0;
            if (inserta.conectar())
            {
                String comando = "Insert into Detalles_Servicios(id_Compra,idServicios)" +
                    "values(" + id_Compra + "," + idServicios + ")";
                Comando = inserta.construye_command(comando);
                if ((inserta.ejecutanonquery()) != 0)
                    regresa = 1;
                else
                    regresa = 0;
                Comando.Connection.Close();
                inserta.desconectar();
            }
            else
                regresa = -1;
            return regresa;
        }




        public void Consulta(GridView gv, string a)
        {

            Conexion consulta = new Conexion();
            SqlDataReader lector;
            if (consulta.conectar())
            {
                consulta.construye_reader("EXECUTE CONSULTA_SOLICITUD_SATATUS '" + a + "'");
                lector = consulta.ejecuta_reader();
                gv.DataSource = lector;
                gv.DataBind();
                consulta.dr.Close();
                consulta.desconectar();
            }
        }
        public void Consulta2(GridView gv, string a, string aa)
        {

            Conexion consulta = new Conexion();
            SqlDataReader lector;
            if (consulta.conectar())
            {
                consulta.construye_reader("EXECUTE CONSULTA_MONTO_GRUPO '" + a + "','" + aa + "'");
                lector = consulta.ejecuta_reader();
                gv.DataSource = lector;
                gv.DataBind();
                consulta.dr.Close();
                consulta.desconectar();
            }
        }
        public void Consulta3(GridView gv, DateTime a, DateTime aa)
        {

            Conexion consulta = new Conexion();
            SqlDataReader lector;
            if (consulta.conectar())
            {
                consulta.construye_reader("EXECUTE CONSULTA_MONTO_FECHAS '" + a.ToShortDateString() + "','" + aa.ToShortDateString() + "'");
                lector = consulta.ejecuta_reader();
                gv.DataSource = lector;
                gv.DataBind();
                consulta.dr.Close();
                consulta.desconectar();
            }
        }
    }
}