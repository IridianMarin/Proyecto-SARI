﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Windows.Forms;

namespace UTP_Ducks.Modelo
{
    public class DatosLogueo
    {
        public int idUsuario { get; set; }
        public int idEmpleado { get; set; }
        public String Tipo_Usuario { get; set; }
        public String Password_2 { get; set; }

        public DatosLogueo()
        {
            idUsuario = 0;
            idEmpleado = 0;
            Tipo_Usuario = "";
            Password_2 = "";
        }

        public DatosLogueo(int u, int e, string t, string p)
        {
            idUsuario = u;
            idEmpleado = e;
            Tipo_Usuario = t;
            Password_2 = p;
        }

            
    }
}