﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using UTP_Ducks.Modelo;
using UTP_Ducks.Controlador;
namespace UTP_Ducks
{
    public partial class Logueo : System.Web.UI.Page
    {
        public string usu = "";
        DatosLogueo obj_usuario = new DatosLogueo();
        Acceso obj_usuario2 = new Acceso();
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            String u = usuario.Text;
            String c = clave.Text;

            if (obj_usuario2.acceso(u,c) == true)
            {
                usu = u;
                Response.Redirect("/Vista/Rh/Perfil.aspx?=" + u);
            }
            else
            {
                usuario.Focus();
                
            }

        }
    }
}