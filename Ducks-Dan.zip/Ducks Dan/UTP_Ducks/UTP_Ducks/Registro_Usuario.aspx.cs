﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace UTP_Ducks
{
    public partial class Registro_Usuario : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void Button1_Click1(object sender, EventArgs e)
        {
            Modelo.Usuario u = new Modelo.Usuario();
            int a = u.regresaID();
            u.idPersona = a;
            u.Tipo_Usuario = nombre.Text;
            string clave = "";
            if (password.Text.Equals(repetir.Text))
            {
                clave = repetir.Text; u.Password_2 = repetir.Text;
                int add = u.altaUsuario();
                if (add == 1)
                {
                    MessageBox.Show("Se registro correctamente!!");
                    Response.Redirect("Logueo.aspx");

                }
                else if (add == 0)
                    MessageBox.Show("Verificar sus datos!! ");
                else
                    MessageBox.Show("Problemas con el servidor \n Espere unos momentos");
                Button1.Visible = false;

            }
            else
                MessageBox.Show("Contraseña incorrecta \n Verifique su contraseña! ");

        }

    }
}