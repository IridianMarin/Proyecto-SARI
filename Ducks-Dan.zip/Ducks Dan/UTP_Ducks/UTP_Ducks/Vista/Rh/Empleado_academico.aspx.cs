﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using UTP_Ducks.Modelo;

namespace UTP_Ducks.RH
{
    public partial class Empleado_academico : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Calendar1.Visible = false;
            Calendar2.Visible = false;

        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (Calendar1.Visible)
            {
                Calendar1.Visible = false;
            }
            else
            {
                Calendar1.Visible = true;
            }


        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            inicio.Text = Calendar1.SelectedDate.ToShortDateString();
            Calendar1.Visible = false;

        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            if (Calendar2.Visible)
            {
                Calendar2.Visible = false;
            }
            else
            {
                Calendar2.Visible = true;
            }


        }

        protected void Calendar2_SelectionChanged(object sender, EventArgs e)
        {
            fin.Text = Calendar2.SelectedDate.ToShortDateString();
            Calendar2.Visible = false;

        }
        protected void BtnEnviar(object sender,EventArgs e)
        {
            Modelo.Empleado ee=new Modelo.Empleado();
            Modelo.Academico a = new Academico();
            int i = a.regresaID();
            a.idEmpleado = i;
            a.TituloObtenido = TextBox1.Text;
            a.Inicio = DateTime.Parse(inicio.Text);
            a.Fin = DateTime.Parse(fin.Text);
            a.Institucion = TextBox4.Text;
            int r = a.alta();
            if (r == 1)
            {
                MessageBox.Show("Datos agregados con exito!!");
                Response.Redirect("/Vista/Rh/Empleado_area.aspx");
            }
            else if (r == 0)
                MessageBox.Show("No se pudo agregar \n Verificar datos");
            else
                MessageBox.Show("Problemas tecnicos favor de esperar");
        }
    }
}