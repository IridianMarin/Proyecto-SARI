﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using UTP_Ducks.Modelo;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using iTextSharp.text.html;
using iTextSharp.text.html.simpleparser;


namespace UTP_Ducks.Vista.Rh
{
    public partial class RH_Consulta : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public override void VerifyRenderingInServerForm(System.Web.UI.Control control)
        {
            /*Verifies that the control is rendered*/
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
        {

        }
        protected void BtnEnviar(object sender, EventArgs e)
        {
            Modelo.Persona p=new Modelo.Persona();
            Modelo.Direccion d = new Modelo.Direccion();
            Modelo.Estudios es = new Modelo.Estudios();
            Modelo.HistorialLaboral h = new Modelo.HistorialLaboral();
            if (DDL.Text.Equals("Consultar"))
            {
                if (TextBox1.Text.Equals("") && TextBox2.Text.Equals("") && TextBox3.Text.Equals(""))
                    MessageBox.Show("Llene los datos que se piden!!");
                else
                {
                    p.Consulta(gvDatos, TextBox1.Text, TextBox2.Text, TextBox3.Text);
                    d.Consulta(gvDir, TextBox1.Text, TextBox2.Text, TextBox3.Text);
                    es.Consulta(gvEstudios, TextBox1.Text, TextBox2.Text, TextBox3.Text);
                    h.Consulta(gvHisto, TextBox1.Text, TextBox2.Text, TextBox3.Text);
                }
            }
            else if (DDL.Text.Equals("Eliminar"))
            {
                if (TextBox1.Text.Equals("") && TextBox2.Text.Equals("") && TextBox3.Text.Equals(""))
                    MessageBox.Show("Llene los datos que se piden!!");
                else
                {
                    p.cambioEstatus(TextBox1.Text, TextBox2.Text, TextBox3.Text);
                    p.Consulta(gvDatos, TextBox1.Text, TextBox2.Text, TextBox3.Text);
                }
            }
            else
                MessageBox.Show("Seleccione la operacion a realizar !!");

        }

        protected void ImageButton3_Click(object sender, ImageClickEventArgs e)
        {

            
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition",
                "attachment;filename=Candidato.PDF");
            Response.Charset = "";
            Response.ContentType = "application/pdf ";
            StringWriter sw = new StringWriter();
            HtmlTextWriter hw = new HtmlTextWriter(sw);
            gvDatos.RenderControl(hw);
            Response.Output.Write(sw.ToString());
            Response.Flush();
            Response.End();
            
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

        }
               
    }
}