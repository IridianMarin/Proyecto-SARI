﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using UTP_Ducks.Modelo;

namespace UTP_Ducks.RH
{
    public partial class Empleado_area : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void BtnEnviar(object sender,EventArgs e)
        {
            Modelo.Area a = new Area();
            Modelo.Empleado ee = new Modelo.Empleado();
            int i = a.regresaID();
            a.idEmpleado = i;
            a.Telefono = Convert.ToInt64(TextBox1.Text);
            a.Descripcion = TextBox3.Text;
            a.Aarea = TextBox2.Text;
            a.Caracteristicas = TextBox4.Text;
            int r = a.alta();
            if (r == 1)
            {
                MessageBox.Show("Datos agregados con exito!!");
                Response.Redirect("/Vista/Rh/Empleado_Habilidad.aspx");
            }
            else if (r == 0)
                MessageBox.Show("No se pudo agregar \n Verificar datos");
            else
                MessageBox.Show("Problemas tecnicos favor de esperar");
        }
    }
}