﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using UTP_Ducks.Modelo;

namespace UTP_Ducks.Vista.Rh
{
    public partial class Psicometrica_2do : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Test t = new Test();

            string r = personalidadEmpuje();
            string r2 = personalidadInfluencia();
            t.PersonalidadEmpuje = r;
            t.PersonalidadOficina = r2;
            int add = t.personalidad(t.regresaIDU());
            if(add==0)
            {
                MessageBox.Show("Asegurese de llenar todas las preguntas");
            }
            else if (add == -1)
            {
                MessageBox.Show("Problemas con el servidor!!");
            }
            else
            {
                MessageBox.Show("Felicidades usted es un potencial candidato \n llene los ultimos datos y espere mas instrucciones!!");
                Response.Redirect("../Vista/Candidato.aspx");
            }

        }
        public int contarDM()
        {
            int contaM1 = 0;
            if (!(string.IsNullOrEmpty(TextBox1.Text)))
                contaM1 = contaM1 + 0;
            else
                contaM1 = contaM1 + 1;
            if (!(string.IsNullOrEmpty(TextBox2.Text)))
                contaM1 = contaM1 + 0;
            else
                contaM1 = contaM1 + 1;
            if (!(string.IsNullOrEmpty(TextBox3.Text)))
                contaM1 = contaM1 + 0;
            else
                contaM1 = contaM1 + 1;
            if (!(string.IsNullOrEmpty(TextBox4.Text)))
                contaM1 = contaM1 + 0;
            else
                contaM1 = contaM1 + 1;
            if (!(string.IsNullOrEmpty(TextBox17.Text)))
                contaM1 = contaM1 + 0;
            else
                contaM1 = contaM1 + 1;
            if (!(string.IsNullOrEmpty(TextBox18.Text)))
                contaM1 = contaM1 + 0;
            else
                contaM1 = contaM1 + 1;
            if (!(string.IsNullOrEmpty(TextBox19.Text)))
                contaM1 = contaM1 + 0;
            else
                contaM1 = contaM1 + 1;
            if (!(string.IsNullOrEmpty(TextBox20.Text)))
                contaM1 = contaM1 + 0;
            else
                contaM1 = contaM1 + 1;
            if (!(string.IsNullOrEmpty(TextBox33.Text)))
                contaM1 = contaM1 + 0;
            else
                contaM1 = contaM1 + 1;
            if (!(string.IsNullOrEmpty(TextBox34.Text)))
                contaM1 = contaM1 + 0;
            else
                contaM1 = contaM1 + 1;
            if (!(string.IsNullOrEmpty(TextBox35.Text)))
                contaM1 = contaM1 + 0;
            else
                contaM1 = contaM1 + 1;
            if (!(string.IsNullOrEmpty(TextBox36.Text)))
                contaM1 = contaM1 + 0;
            else
                contaM1 = contaM1 + 1;
            if (!(string.IsNullOrEmpty(TextBox49.Text)))
                contaM1 = contaM1 + 0;
            else
                contaM1 = contaM1 + 1;
            if (!(string.IsNullOrEmpty(TextBox50.Text)))
                contaM1 = contaM1 + 0;
            else
                contaM1 = contaM1 + 1;
            if (!(string.IsNullOrEmpty(TextBox51.Text)))
                contaM1 = contaM1 + 0;
            else
                contaM1 = contaM1 + 1;
            if (!(string.IsNullOrEmpty(TextBox52.Text)))
                contaM1 = contaM1 + 0;
            else
                contaM1 = contaM1 + 1;
            return contaM1;
        }
        public int contarDL()
        {
            int contaL1 = 0;
            if (!(string.IsNullOrEmpty(TextBox97.Text)))
                contaL1 = contaL1 + 0;
            else
                contaL1 = contaL1 + 1;
            if (!(string.IsNullOrEmpty(TextBox98.Text)))
                contaL1 = contaL1 + 0;
            else
                contaL1 = contaL1 + 1;
            if (!(string.IsNullOrEmpty(TextBox99.Text)))
                contaL1 = contaL1 + 0;
            else
                contaL1 = contaL1 + 1;
            if (!(string.IsNullOrEmpty(TextBox100.Text)))
                contaL1 = contaL1 + 0;
            else
                contaL1 = contaL1 + 1;
            if (!(string.IsNullOrEmpty(TextBox112.Text)))
                contaL1 = contaL1 + 0;
            else
                contaL1 = contaL1 + 1;
            if (!(string.IsNullOrEmpty(TextBox113.Text)))
                contaL1 = contaL1 + 0;
            else
                contaL1 = contaL1 + 1;
            if (!(string.IsNullOrEmpty(TextBox114.Text)))
                contaL1 = contaL1 + 0;
            else
                contaL1 = contaL1 + 1;
            if (!(string.IsNullOrEmpty(TextBox115.Text)))
                contaL1 = contaL1 + 0;
            else
                contaL1 = contaL1 + 1;
            if (!(string.IsNullOrEmpty(TextBox129.Text)))
                contaL1 = contaL1 + 0;
            else
                contaL1 = contaL1 + 1;
            if (!(string.IsNullOrEmpty(TextBox130.Text)))
                contaL1 = contaL1 + 0;
            else
                contaL1 = contaL1 + 1;
            if (!(string.IsNullOrEmpty(TextBox131.Text)))
                contaL1 = contaL1 + 0;
            else
                contaL1 = contaL1 + 1;
            if (!(string.IsNullOrEmpty(TextBox132.Text)))
                contaL1 = contaL1 + 0;
            else
                contaL1 = contaL1 + 1;
            if (!(string.IsNullOrEmpty(TextBox145.Text)))
                contaL1 = contaL1 + 0;
            else
                contaL1 = contaL1 + 1;
            if (!(string.IsNullOrEmpty(TextBox146.Text)))
                contaL1 = contaL1 + 0;
            else
                contaL1 = contaL1 + 1;
            if (!(string.IsNullOrEmpty(TextBox147.Text)))
                contaL1 = contaL1 + 0;
            else
                contaL1 = contaL1 + 1;
            if (!(string.IsNullOrEmpty(TextBox148.Text)))
                contaL1 = contaL1 + 0;
            else
                contaL1 = contaL1 + 1;

            return contaL1;
        }
        public int CalculoD()
        {
            int resultadoD = 0;
            return resultadoD = contarDL() - contarDM();
        }
        public string personalidadEmpuje()
        {
            string personaly = "";
            int puntaje = Convert.ToInt32(CalculoD());
            if (puntaje > -5 && puntaje <= 5)
            {
                personaly = "Creativo";
                return personaly;
            }
            if (puntaje > -10 && puntaje <= -6)
            {
                personaly = "Individualidad";
                return personaly;
            }
            if (puntaje > 5 && puntaje <= 7)
            {
                personaly = "Paciencia";
                return personaly;
            }
            if (puntaje > 7 && puntaje <= 10)
            {
                personaly = "Buena Voluntad";
                return personaly;
            }
            return personaly;
        }
        public int contarIM()
        {
            int contaM1 = 0;
            if (!(string.IsNullOrEmpty(TextBox5.Text)))
                contaM1 = contaM1 + 0;
            else
                contaM1 = contaM1 + 1;
            if (!(string.IsNullOrEmpty(TextBox6.Text)))
                contaM1 = contaM1 + 0;
            else
                contaM1 = contaM1 + 1;
            if (!(string.IsNullOrEmpty(TextBox7.Text)))
                contaM1 = contaM1 + 0;
            else
                contaM1 = contaM1 + 1;
            if (!(string.IsNullOrEmpty(TextBox8.Text)))
                contaM1 = contaM1 + 0;
            else
                contaM1 = contaM1 + 1;
            if (!(string.IsNullOrEmpty(TextBox21.Text)))
                contaM1 = contaM1 + 0;
            else
                contaM1 = contaM1 + 1;
            if (!(string.IsNullOrEmpty(TextBox22.Text)))
                contaM1 = contaM1 + 0;
            else
                contaM1 = contaM1 + 1;
            if (!(string.IsNullOrEmpty(TextBox23.Text)))
                contaM1 = contaM1 + 0;
            else
                contaM1 = contaM1 + 1;
            if (!(string.IsNullOrEmpty(TextBox24.Text)))
                contaM1 = contaM1 + 0;
            else
                contaM1 = contaM1 + 1;
            if (!(string.IsNullOrEmpty(TextBox37.Text)))
                contaM1 = contaM1 + 0;
            else
                contaM1 = contaM1 + 1;
            if (!(string.IsNullOrEmpty(TextBox38.Text)))
                contaM1 = contaM1 + 0;
            else
                contaM1 = contaM1 + 1;
            if (!(string.IsNullOrEmpty(TextBox39.Text)))
                contaM1 = contaM1 + 0;
            else
                contaM1 = contaM1 + 1;
            if (!(string.IsNullOrEmpty(TextBox40.Text)))
                contaM1 = contaM1 + 0;
            else
                contaM1 = contaM1 + 1;
            if (!(string.IsNullOrEmpty(TextBox53.Text)))
                contaM1 = contaM1 + 0;
            else
                contaM1 = contaM1 + 1;
            if (!(string.IsNullOrEmpty(TextBox54.Text)))
                contaM1 = contaM1 + 0;
            else
                contaM1 = contaM1 + 1;
            if (!(string.IsNullOrEmpty(TextBox55.Text)))
                contaM1 = contaM1 + 0;
            else
                contaM1 = contaM1 + 1;
            if (!(string.IsNullOrEmpty(TextBox56.Text)))
                contaM1 = contaM1 + 0;
            else
                contaM1 = contaM1 + 1;
            return contaM1;
        }
        public int contarIL()
        {
            int contaL1 = 0;
            if (!(string.IsNullOrEmpty(TextBox101.Text)))
                contaL1 = contaL1 + 0;
            else
                contaL1 = contaL1 + 1;
            if (!(string.IsNullOrEmpty(TextBox102.Text)))
                contaL1 = contaL1 + 0;
            else
                contaL1 = contaL1 + 1;
            if (!(string.IsNullOrEmpty(TextBox128.Text)))
                contaL1 = contaL1 + 0;
            else
                contaL1 = contaL1 + 1;
            if (!(string.IsNullOrEmpty(TextBox103.Text)))
                contaL1 = contaL1 + 0;
            else
                contaL1 = contaL1 + 1;
            if (!(string.IsNullOrEmpty(TextBox116.Text)))
                contaL1 = contaL1 + 0;
            else
                contaL1 = contaL1 + 1;
            if (!(string.IsNullOrEmpty(TextBox117.Text)))
                contaL1 = contaL1 + 0;
            else
                contaL1 = contaL1 + 1;
            if (!(string.IsNullOrEmpty(TextBox118.Text)))
                contaL1 = contaL1 + 0;
            else
                contaL1 = contaL1 + 1;
            if (!(string.IsNullOrEmpty(TextBox119.Text)))
                contaL1 = contaL1 + 0;
            else
                contaL1 = contaL1 + 1;
            if (!(string.IsNullOrEmpty(TextBox133.Text)))
                contaL1 = contaL1 + 0;
            else
                contaL1 = contaL1 + 1;
            if (!(string.IsNullOrEmpty(TextBox134.Text)))
                contaL1 = contaL1 + 0;
            else
                contaL1 = contaL1 + 1;
            if (!(string.IsNullOrEmpty(TextBox135.Text)))
                contaL1 = contaL1 + 0;
            else
                contaL1 = contaL1 + 1;
            if (!(string.IsNullOrEmpty(TextBox136.Text)))
                contaL1 = contaL1 + 0;
            else
                contaL1 = contaL1 + 1;
            if (!(string.IsNullOrEmpty(TextBox149.Text)))
                contaL1 = contaL1 + 0;
            else
                contaL1 = contaL1 + 1;
            if (!(string.IsNullOrEmpty(TextBox150.Text)))
                contaL1 = contaL1 + 0;
            else
                contaL1 = contaL1 + 1;
            if (!(string.IsNullOrEmpty(TextBox151.Text)))
                contaL1 = contaL1 + 0;
            else
                contaL1 = contaL1 + 1;
            if (!(string.IsNullOrEmpty(TextBox152.Text)))
                contaL1 = contaL1 + 0;
            else
                contaL1 = contaL1 + 1;

            return contaL1;
        }
        public int CalculoI()
        {
            int resultadoI = 0;
            return resultadoI = contarIL() - contarIM();
        }
        public string personalidadInfluencia()
        {
            string personaly2 = "";
            int puntaje = Convert.ToInt32(CalculoI());
            if (puntaje > -5 && puntaje <= 5)
            {
                personaly2 = "Habilidad de Contacto";
                return personaly2;
            }
            if (puntaje > -10 && puntaje <= -6)
            {
                personaly2 = "Confianza en sí";
                return personaly2;
            }
            if (puntaje > 5 && puntaje <= 7)
            {
                personaly2 = "Persistencia";
                return personaly2;
            }
            if (puntaje > 7 && puntaje <= 10)
            {
                personaly2 = "Adaptabilidad";
                return personaly2;
            }
            return personaly2;
        }
    }
}
