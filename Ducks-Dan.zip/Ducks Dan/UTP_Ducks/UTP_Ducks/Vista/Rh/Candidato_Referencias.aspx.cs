﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using UTP_Ducks.Modelo;

namespace UTP_Ducks.RH
{
    public partial class Candidato_Referencias : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void nuevo_Click(object sender, EventArgs e)
        {
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";
            
        }
        protected void BtnEnviar(object sender,EventArgs e)
        {
            Modelo.Referencias re = new Referencias();
            int ii = re.regresaID();
            re.idCandidato = ii;
            re.NombreReferen = TextBox1.Text;
            re.DireccionReferen = TextBox2.Text;
            re.OcupacionReferen = TextBox3.Text;
            re.TelefonoReferen = Convert.ToInt64(TextBox4.Text);
            int r = re.alta();
            if (r == 1)
            {              
                    MessageBox.Show("Datos agregados con exito !!");
                    Response.Redirect("/vista/Rh/Candidato_estudios.aspx");
            }
            else if (r == 0)
                MessageBox.Show("No se pudo agregar \n Verificar datos");
            else
                MessageBox.Show("Problemas tecnicos... \n \t Favor de esperar");
        }
    }
}