﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using UTP_Ducks.Modelo;

namespace UTP_Ducks.RH
{
    public partial class Candidato_informacion_Idioma : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void BtnEnviar(object sender,EventArgs e)
        {
            Modelo.Idiomas idi = new Idiomas();
            Modelo.Candidatos c = new Candidatos();
            Modelo.MasInformacion m = new MasInformacion();
            int i = idi.regresaID();
            idi.idCandidatos = i;
            idi.Nombre = TextBox1.Text;
            idi.nivel = level.Text;
            idi.Descripcion = TextBox2.Text;
            int ii=m.regresaID();
            m.idCandidatos = ii;
            m.Herramientas_Oficina = TextBox3.Text;
            m.Herra_Info = TextBox4.Text;
            m.Cursos = TextBox5.Text;
            m.ConocimientosTecn = TextBox6.Text;
            m.ConocimientosFinanci = TextBox7.Text;
            int r = idi.alta();
            int rr = m.alta();
            if (r == 1 && rr==1)
            {
                MessageBox.Show("Datos agregados con exito!!");
                Response.Redirect("/Vista/Rh/Candidato_preferenciaLaboral.aspx");
            }
            else if (r == 0 && rr==0)
                MessageBox.Show("No se pudo agregar \n Verificar datos");
            else
                MessageBox.Show("Problemas tecnicos... \n \t Favor de esperar");
        }
    }
}