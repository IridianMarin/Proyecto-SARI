﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using UTP_Ducks.Modelo;

namespace UTP_Ducks.RH
{
    public partial class Candidato_preferenciaLaboral : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        protected void BtnEnviar(object sender,EventArgs e)
        {
            Modelo.PreferenciasLaborales pl = new PreferenciasLaborales();
            Modelo.Candidatos c = new Candidatos();
            int i = pl.regresaID();
            pl.idCandidatos = i;
            pl.Turno = turno.Text;
            pl.Area = area.Text;
            pl.Puesto = p.Text;
            pl.Sueldo = Convert.ToDouble(s.Text);
            pl.Objetivo = o.Text;
            pl.Extra = ext.Text;
            int r = pl.alta();
            if (r == 1)
            {
                MessageBox.Show("Datos agregados con exito!!");
                Response.Redirect("/vista/Rh/Empleado.aspx");
            }
            else if (r == 0)
                MessageBox.Show("No se pudo agregar \n Verificar datos");
            else
                MessageBox.Show("Problemas tecnicos... \n \t Favor de esperar");
        }
    }
}