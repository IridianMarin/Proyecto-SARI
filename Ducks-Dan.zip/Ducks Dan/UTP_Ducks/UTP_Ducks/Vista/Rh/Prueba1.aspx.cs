﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using UTP_Ducks.Modelo;

namespace UTP_Ducks.Vista.Rh
{
    public partial class Prueba1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        public int CalificarHS()
        {
            int HS = 0;
            if (RadioButton2.Checked == true)
                HS = HS + 20;
            if (RadioButton3.Checked == true)
                HS = HS + 20;
            if (RadioButton16.Checked == true)
                HS = HS + 20;
            if (RadioButton18.Checked == true)
                HS = HS + 20;
            if (RadioButton24.Checked == true)
                HS = HS + 20;
            return HS;
        }
        public int CalificarCDRH()
        {
            int CDRH = 0;
            if (RadioButton4.Checked == true)
                CDRH = CDRH + 25;
            if (RadioButton6.Checked == true)
                CDRH = CDRH + 25;
            if (RadioButton20.Checked == true)
                CDRH = CDRH + 25;
            if (RadioButton23.Checked == true)
                CDRH = CDRH + 25;
            return CDRH;
        }
        public int CalificarCEPI()
        {
            int CEPI = 0;

            if (RadioButton7.Checked == true)
                CEPI = CEPI + 16;
            if (RadioButton9.Checked == true)
                CEPI = CEPI + 16;
            if (RadioButton12.Checked == true)
                CEPI = CEPI + 16;
            if (RadioButton14.Checked == true)
                CEPI = CEPI + 16;
            if (RadioButton19.Checked == true)
                CEPI = CEPI + 16;
            if (RadioButton21.Checked == true)
                CEPI = CEPI + 16;
            return CEPI;
        }
        public int CalificarHERH()
        {
            int HERH = 0;

            if (RadioButton7.Checked == true)
                HERH = HERH + 20;
            if (RadioButton9.Checked == true)
                HERH = HERH + 20;
            if (RadioButton12.Checked == true)
                HERH = HERH + 20;
            if (RadioButton14.Checked == true)
                HERH = HERH + 20;
            if (RadioButton19.Checked == true)
                HERH = HERH + 20;
            return HERH;
        }
        public int CalificarSCTRH()
        {
            int SCTRH = 0;

            if (RadioButton7.Checked == true)
                SCTRH = SCTRH + 16;
            if (RadioButton9.Checked == true)
                SCTRH = SCTRH + 16;
            if (RadioButton12.Checked == true)
                SCTRH = SCTRH + 16;
            if (RadioButton14.Checked == true)
                SCTRH = SCTRH + 16;
            if (RadioButton19.Checked == true)
                SCTRH = SCTRH + 16;
            if (RadioButton22.Checked == true)
                SCTRH = SCTRH + 16;
            return SCTRH;
        }

        protected void btnPrimeraPrue_Click(object sender, EventArgs e)
        {
            //nombre del area deseada v1(nombre) v2(nombre) v3(nombre) v4(nombre) v5(nombre)
            string dept = "";
            Test t = new Test();

            int v1 = CalificarHS();
            int v2 = CalificarCDRH();
            int v3 = CalificarCEPI();
            int v4 = CalificarHERH();
            int v5 = CalificarSCTRH();

            if (v1 > v2 && v1 > v3 && v1 > v4 && v1 > v5)
                dept = "Valor 1";
            else if (v2 > v1 && v2 > v3 && v2 > v4 && v2 > v5)
                dept = "Valor2";
            else if (v3 > v1 && v3 > v2 && v3 > v4 && v3 > v5)
                dept = "valor 3";
            else if (v4 > v1 && v4 > v2 && v4 > v3 && v4 > v5)
                dept = "Valor4";
            else
                dept = "Valor 5";
            t.Departamento = dept;
            t.HS = v1;
            t.CDRH = v2;
            t.CEPI = v3;
            t.HERI = v4;
            t.SCTRI = v5;
            int add = t.alta();
            if (add == 1)
            {
                MessageBox.Show("Sus valores son: "+v1+", "+v2+", "+v3+", "+v4+", "+v5);
                MessageBox.Show("Test Resuelto completamente \n Siguiente test a realizar!!");
                Response.Redirect("../../Vista/Rh/Psicometrica_2do.aspx");
            }
            else if (add == 0)
            {
                MessageBox.Show("Bo se pudo enviar el test \n Favor de llenar todas las preguntas!!");
            }
            else
                MessageBox.Show("Problemas Tecnicos!!\n Favor de esperar","Stop",MessageBoxButtons.OKCancel,MessageBoxIcon.Error);
        }
    }
}