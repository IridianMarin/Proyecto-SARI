﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace UTP_Ducks.RH
{
    public partial class Empleado : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            btnEnviar.Visible = true;
        }
        protected void BtnEnviar(object sender, EventArgs e)
        {
            Modelo.Persona p = new Modelo.Persona();
            Modelo.Empleado em = new Modelo.Empleado();
            int i = p.regresaID();
            em.idPersona = i;
            em.Area = area.Text;
            em.Puesto = puesto.Text;
            em.foto = file_foto.ToString();
            int r = em.alta();
            if (r == 1)
            {
                MessageBox.Show("Empleado agregado con exito");
                Response.Redirect("/Vista/Rh/Empleado_academico.aspx");
            }
            else if (r == 0)
                MessageBox.Show("No se pudo agregar el empleado \n Verificar datos");
            else
                MessageBox.Show("Problemas tecnicos favor de esperar");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Boolean correcto = false;
            if (file_foto.HasFile)
            {
                string extencionArchivo = System.IO.Path.GetExtension(file_foto.FileName).ToLower();

                string[] extencionesPermitidas = { ".png", ".jpg", ".jpeg" };

                for (int i = 0; i < extencionesPermitidas.Length; i++)
                {
                    if (extencionArchivo == extencionesPermitidas[i])
                    {
                        correcto = true;
                    }
                }

                if (correcto == true)
                {
                    ViewState["Foto"] = System.IO.Path.GetFileName(file_foto.FileName);
                    file_foto.SaveAs(Server.MapPath("~/") + ViewState["Foto"]);

                    img.ImageUrl = "~/" + ViewState["Foto"];
                }
            }
        }
    }
}