﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using UTP_Ducks.Modelo;

namespace UTP_Ducks.RH
{
    public partial class Persona : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Calendar1.Visible = false;
            btnEnviar.Visible = true;
        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            naci.Text = Calendar1.SelectedDate.ToShortDateString();
            Calendar1.Visible = false;

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (Calendar1.Visible)
            {
                Calendar1.Visible = false;
            }
            else
            {
                Calendar1.Visible = true;
            }

        }

        protected void btnEnviar1(object sender, EventArgs e)
        {
            Modelo.Persona p = new Modelo.Persona();
            p.Nombre = nombre.Text;
            string estatus = "Activo";
            string genero = "";
            p.ApPaterno = apP.Text;
            p.ApMaterno = apM.Text;
            p.Curp = curp.Text;
            p.RFC = rfc.Text;
            if (RadioButton1.Checked)
            {
                genero = "Hombre";
            }
            else
                genero = "Mujer";
            p.Genero = genero;
            p.FechaNacimiento = DateTime.Parse(naci.Text);
            p.Estado_civil = estadoC.Text;
            p.Estatus = estatus;
            int add = p.altaPersona();
            if (add == 1)
            {
                MessageBox.Show("Datos guardados correctamente!!");
                Response.Redirect("/Vista/Rh/Direccion.aspx");

            }
            else if (add == 0)
                MessageBox.Show("Verificar sus datos!! ");
            else
                MessageBox.Show("Problemas con el servidor \n Espere unos momentos");
        }
    }
}