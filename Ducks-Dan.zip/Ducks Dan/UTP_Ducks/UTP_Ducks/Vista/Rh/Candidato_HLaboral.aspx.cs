﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using UTP_Ducks.Modelo;

namespace UTP_Ducks.RH
{
    public partial class Candidato_HLaboral : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Calendar1.Visible = false;
            Calendar2.Visible = false;
            btnEnviar.Visible = true;
            Button1.Visible = false;

        }

        protected void Calendar2_SelectionChanged(object sender, EventArgs e)
        {
            fin.Text = Calendar2.SelectedDate.ToShortDateString();
            Calendar2.Visible = false;


        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            inicio.Text = Calendar1.SelectedDate.ToShortDateString();
            Calendar1.Visible = false;

        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (Calendar1.Visible)
            {
                Calendar1.Visible = false;
            }
            else
            {
                Calendar1.Visible = true;
            }

        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            if (Calendar2.Visible)
            {
                Calendar2.Visible = false;
            }
            else
            {
                Calendar2.Visible = true;
            }


        }

        protected void nuevo_Click(object sender, EventArgs e)
        {

            empresa.Text = "";
            inicio.Text = "";
            fin.Text = "";
            area.Text = "";
            puesto.Text = "";
            industria.Text = "";
            sueldo.Text = "";
            motivo.Text = "";
            jefeIm.Text = "";
            puesJefe.Text = "";
            telJefe.Text = "";
            contacto.Text = "";
            comentario.Text = "";
            btnEnviar.Visible = true;

        }
        protected void BtnEnviar(object sender, EventArgs e)
        {
            Modelo.HistorialLaboral hl = new HistorialLaboral();
            Modelo.Candidatos c = new Candidatos();
            int ii = hl.regresaID();
            hl.idCandidatos = ii;
            hl.Empresa = empresa.Text;
            // Display using pt-BR culture's short date format
            CultureInfo culture = new CultureInfo("en-NZ");
            DateTime i = DateTime.ParseExact(inicio.Text, "d", culture);  // Displays dd/MM/yyyy
            DateTime f = DateTime.ParseExact(fin.Text, "d", culture);
            hl.Fecha_Inicio = i;
            hl.Fecha_Fin = f;
            hl.Area = area.Text;
            hl.Puesto = puesto.Text;
            hl.Industri = industria.Text;
            hl.Sueldo = Convert.ToDouble(sueldo.Text);
            hl.Motivo_Salida = motivo.Text;
            hl.Jefe_Imediato = jefeIm.Text;
            hl.Puesto_Jefe = puesJefe.Text;
            hl.Telefono_Jefe = Convert.ToInt64(telJefe.Text);
            hl.Contacto = Convert.ToInt32(contacto.Text);
            hl.Comentarios = comentario.Text;
            int r = hl.alta();
            if (r == 1)
            {
                MessageBox.Show("Datos agregados con exito !!");
                    Response.Redirect("/vista/Rh/Candidato_informacion-Idioma.aspx");
            }
            else if (r == 0)
                MessageBox.Show("No se pudo agregar \n Verificar datos");
            else
                MessageBox.Show("Problemas tecnicos... \n \t Favor de esperar");
        }
    }
}