﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace UTP_Ducks.RH
{
    public partial class Direccion : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (IsPostBack == false)
            {
                RegionInfo reginfo;                            //Definiendo un objeto RegionInfo    
                //Creando una lista de todas las culturas.....
                CultureInfo[] cultInfoList = CultureInfo.GetCultures(CultureTypes.AllCultures);
                //Explorando todas las culturas (no todas retornan paises que se encuentran en RegionInfo            
                foreach (CultureInfo cultInfo in cultInfoList)
                {
                    //Se puede generar una excepción por no corresponder un culture info LCID con 
                    //un un código existente en RegInfo (por ejemplo Cuba) en ese caso se captura 
                    //la excepción y continua el lazo
                    try
                    {
                        //Crear una clase reginfo para traer los nombres del país
                        reginfo = new RegionInfo(cultInfo.LCID);                //Se crea una reg info del pais
                        //Crear un ListItem para almacenar el nombre del país y el código de dos letras ISO 
                        ListItem li = new ListItem(reginfo.DisplayName, reginfo.TwoLetterISORegionName);
                        //Debido a que diferentes culture info pueden generar diferentes varias veces el
                        //mismo pais, verificar que el pais ya no se encuentre.
                        if (pais.Items.IndexOf(li) < 1)
                        { pais.Items.Add(li); }
                    }
                    catch //Captura de la excepción por falta de correspondencia de código
                    {
                        ;
                    }
                }
            }
        }
        protected void BTN_Enviar(object sender, EventArgs e)
        {
            Modelo.Direccion d = new Modelo.Direccion();
            Modelo.Requiere_de rd = new Modelo.Requiere_de();
            Modelo.Persona p = new Modelo.Persona();
            d.Calle = calle.Text;
            d.CodigoPostal = Convert.ToInt32(cp.Text);
            d.Estado = estado.Text;
            d.NumExterior = Convert.ToInt32(noExt.Text);
            d.NumInterior = noInt.Text;
            d.Pais = pais.Text;
            d.Tipo_domicilio = tipo.Text;
            d.Colonia = colonia.Text;
            int add = d.altaDireccion();
            if (add == 1)
            {
                int i = d.regresaID();
                int ii = p.regresaID();
                rd.idPersona = ii;
                rd.idDireccion = i;
                int h = rd.altaRequiere_de();
                if (h == 1)
                {
                    MessageBox.Show("Datos guardados correctamente!! \n \n\t Se ha registrado exitosamente !!");
                    Response.Redirect("/Registro_Usuario.aspx");
                }
                else
                    MessageBox.Show("Verifica tus datos !!!");
            }
            else if (add == 0)
                MessageBox.Show("Verificar sus datos!! ");
            else
                MessageBox.Show("Problemas con el servidor \n Espere unos momentos");
        }

    }
}