﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UTP_Ducks.Modelo;
using System.Windows.Forms;

namespace UTP_Ducks.RH
{
    public partial class Candidato : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
        protected void BtnEnviar(object sender,EventArgs e)
        {
            Modelo.Candidatos c = new Candidatos();
            Modelo.Contactos cc = new Contactos();
            Modelo.Telefono t = new Telefono();
            Modelo.Persona p = new Modelo.Persona();
            int i = c.regresaID();
            int tel01 = Convert.ToInt32(tel1.Text);
            long tel02 = Convert.ToInt64(tel2.Text);
            String t1 = "Celular";
            String t2 = "Telefono de casa";
            c.idPersona = i;
            c.Email = email.Text;
            c.No_IMSS = Convert.ToInt64(Nimss.Text);
            cc.idPersona = i;
            t.Numero = tel01;
            t.Tipo = t2;
            int rrr = t.altaTelefono();
            int r = c.alta();
            int h = t.altaTelefono2(tel02,t1);
            if (r == 1 && rrr==1 && h==1)
            {
                int ii = t.regresaID();
                cc.idTelefono = ii;
                cc.altaContactos();
                MessageBox.Show("Candidato agregado con exito");
                Response.Redirect("/vista/Rh/Candidato_Referencias.aspx");
            }
            else if (r == 0 && rrr==0 && h==0)
                MessageBox.Show("No se pudo agregar al Candidato \n Verificar datos");
            else
                MessageBox.Show("Problemas tecnicos... \n \t Favor de esperar");            
        }
    }
}