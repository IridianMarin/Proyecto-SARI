﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using UTP_Ducks.Modelo;

namespace UTP_Ducks.RH
{
    public partial class Candidato_estudios : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Calendar1.Visible = false;
            Calendar2.Visible = false;
            btnEnviar.Visible = true;
            if (IsPostBack == false)
            {
                RegionInfo reginfo;                            //Definiendo un objeto RegionInfo    
                //Creando una lista de todas las culturas.....
                CultureInfo[] cultInfoList = CultureInfo.GetCultures(CultureTypes.AllCultures);
                //Explorando todas las culturas (no todas retornan paises que se encuentran en RegionInfo            
                foreach (CultureInfo cultInfo in cultInfoList)
                {
                    //Se puede generar una excepción por no corresponder un culture info LCID con 
                    //un un código existente en RegInfo (por ejemplo Cuba) en ese caso se captura 
                    //la excepción y continua el lazo
                    try
                    {
                        //Crear una clase reginfo para traer los nombres del país
                        reginfo = new RegionInfo(cultInfo.LCID);                //Se crea una reg info del pais
                        //Crear un ListItem para almacenar el nombre del país y el código de dos letras ISO 
                        ListItem li = new ListItem(reginfo.DisplayName, reginfo.TwoLetterISORegionName);
                        //Debido a que diferentes culture info pueden generar diferentes varias veces el
                        //mismo pais, verificar que el pais ya no se encuentre.
                        if (Paiss.Items.IndexOf(li) < 1)
                        { Paiss.Items.Add(li); }
                    }
                    catch //Captura de la excepción por falta de correspondencia de código
                    {
                        ;
                    }
                }
            }

        }

        protected void inicio_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            fi.Text = Calendar1.SelectedDate.ToShortDateString();
            Calendar1.Visible = false;
        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (Calendar1.Visible)
            {
                Calendar1.Visible = false;
            }
            else
            {
                Calendar1.Visible = true;
            }

        }

        protected void Calendar2_SelectionChanged(object sender, EventArgs e)
        {
            ft.Text = Calendar2.SelectedDate.ToShortDateString();
            Calendar2.Visible = false;
        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            if (Calendar2.Visible)
            {
                Calendar2.Visible = false;
            }
            else
            {
                Calendar2.Visible = true;
            }

        }
        protected void BtnEnviar(object sender, EventArgs e)
        {
            Modelo.Estudios es = new Estudios();
            Modelo.Candidatos c = new Candidatos();
            int i = es.regresaID();
            es.idCandidato = i;
            es.Nivel_Estudios = nivel.Text;
            es.Pais = Paiss.Text;
            es.Institucion = inst.Text;
            es.Area=area.Text;
            es.Titulo = titulo.Text;
            // Display using pt-BR culture's short date format
            CultureInfo culture = new CultureInfo("en-NZ");
            DateTime ii = DateTime.ParseExact(fi.Text, "d", culture);  // Displays dd/MM/yyyy
            DateTime f = DateTime.ParseExact(ft.Text, "d", culture);
            es.Fecha_Inicio = ii;
            es.Fecha_Terminos = f;
            es.Promedio = Convert.ToDouble(promedio.Text);
            int r = es.alta();
            if (r == 1)
            {
                MessageBox.Show("Datos agregados con exito");
                Response.Redirect("/vista/Rh/Candidato_HLaboral.aspx");
            }
            else if (r == 0)
                MessageBox.Show("No se pudo agregar \n Verificar datos");
            else
                MessageBox.Show("Problemas tecnicos... \n \t Favor de esperar");
        }
    }
}