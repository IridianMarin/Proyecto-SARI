﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using UTP_Ducks.Modelo;

namespace UTP_Ducks.RH
{
    public partial class Empleado_Habilidad : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            btnEnviar.Visible = true;
        }

        protected void nuevo_Click(object sender, EventArgs e)
        {
            TextBox1.Text = "";
            TextBox2.Text = "";
            btnEnviar.Visible = true;
        }
        protected void BtnEnviar(object sender,EventArgs e)
        {
            Modelo.Habilidad h=new Habilidad();
            Modelo.Empleado ee = new Modelo.Empleado();
            int i = h.regresaID();
            h.idEmpleado = i;
            h.Descripcion = TextBox2.Text;
            h.Tipo = TextBox1.Text;
            int r = h.alta();
            if (r == 1)
            {
                MessageBox.Show("Datos agregados con exito!!");
                    Response.Redirect("/Vista/Rh/Empleado_Jornada.aspx");
            }
            else if (r == 0)
                MessageBox.Show("No se pudo agregar \n Verificar datos");
            else
                MessageBox.Show("Problemas tecnicos favor de esperar");
        }
    }
}