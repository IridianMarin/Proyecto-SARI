﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using UTP_Ducks.Modelo;

namespace UTP_Ducks.RH
{
    public partial class Empleado_jornada : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Calendar1.Visible = false;
            Calendar2.Visible = false;

        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (Calendar1.Visible)
            {
                Calendar1.Visible = false;
            }
            else
            {
                Calendar1.Visible = true;
            }


        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            entrada.Text = Calendar1.SelectedDate.ToShortDateString();
            Calendar1.Visible = false;

        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            if (Calendar2.Visible)
            {
                Calendar2.Visible = false;
            }
            else
            {
                Calendar2.Visible = true;
            }


        }

        protected void Calendar2_SelectionChanged(object sender, EventArgs e)
        {
            salida.Text = Calendar2.SelectedDate.ToShortDateString();
            Calendar2.Visible = false;
        }
        protected void BtnEnviar(object sender, EventArgs e)
        {
            Modelo.Jornada j = new Jornada();
            Modelo.Asiste a = new Asiste();
            Modelo.Empleado ee = new Modelo.Empleado();
            j.Turno = turno.Text;
            j.Tipo = tipo.Text;
            j.Dia_Semana = dia.Text;
            j.HoraEntrada = entrada.Text;
            j.HoraSalida = salida.Text;
            int r = j.alta();
            if (r == 1)
            {
                int i = j.regresaID();
                int ii = ee.regresaID2();
                a.idEmpleado = ii;
                a.idJornada = i;
                a.alta();
                MessageBox.Show("Datos agregados con exito!!");
                    Response.Redirect("/Inicio.aspx");
            }
            else if (r == 0)
                MessageBox.Show("No se pudo agregar \n Verificar datos");
            else
                MessageBox.Show("Problemas tecnicos favor de esperar");
        }
    }
}