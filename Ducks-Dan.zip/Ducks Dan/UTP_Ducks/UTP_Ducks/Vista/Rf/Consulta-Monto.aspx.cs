﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UTP_Ducks.Modelo;
using System.Windows.Forms;
using System.Globalization;

namespace UTP_Ducks.Vista.Rf
{
    public partial class Consulta_Monto : System.Web.UI.Page
    {
        Modelo.Productos p = new Productos();
        Detalles_Servicios ds = new Detalles_Servicios();
        protected void Page_Load(object sender, EventArgs e)
        {
            p.carga(DropDownList2);
            Calendar1.Visible = false;
            Calendar2.Visible = false;

        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (Calendar1.Visible)
            {
                Calendar1.Visible = false;
            }
            else
            {
                Calendar1.Visible = true;
            }
        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            inicio.Text = Calendar1.SelectedDate.ToShortDateString();
            Calendar1.Visible = false;
        }

        protected void ImageButton2_Click(object sender, ImageClickEventArgs e)
        {
            if (Calendar2.Visible)
            {
                Calendar2.Visible = false;
            }
            else
            {
                Calendar2.Visible = true;
            }
        }

        protected void Calendar2_SelectionChanged(object sender, EventArgs e)
        {
            fin.Text = Calendar2.SelectedDate.ToShortDateString();
            Calendar2.Visible = false;
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            if (DropDownList1.Text.Equals("Normal"))
            {
                ds.Consulta2(GridView1, "Normal", DropDownList2.Text);
            }
            else if (DropDownList1.Text.Equals("Ordinaria"))
            {
                ds.Consulta2(GridView1, "Ordinaria", DropDownList2.Text);
            }
            else if (DropDownList1.Text.Equals("Extraordinaria"))
            {
                ds.Consulta2(GridView1, "Extraordinaria", DropDownList2.Text);
            }
            else
                MessageBox.Show("Seleccione una opcion ","Warring",MessageBoxButtons.OKCancel,MessageBoxIcon.Warning);
        }

        protected void Button2_Click(object sender, EventArgs e)
        {            
            // Display using pt-BR culture's short date format
            CultureInfo culture = new CultureInfo("pt-BR");      
            DateTime i=DateTime.ParseExact(inicio.Text,"d", culture);  // Displays 15/3/2008
            DateTime f = DateTime.ParseExact(fin.Text, "d", culture);

            if (inicio.Text.Equals("") && fin.Text.Equals(""))
                MessageBox.Show("Seleccione las fechas a consultar!!");
            else
                ds.Consulta3(GridView2, i, f);
        }

    }
}