﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UTP_Ducks.Modelo;
using System.Windows.Forms;

namespace UTP_Ducks.RF
{
    public partial class Servicio : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnEnviar_Click(object sender, EventArgs e)
        {
            Modelo.Servicios s = new Modelo.Servicios();
            Modelo.Atiende a = new Modelo.Atiende();
            s.Precio = Convert.ToDouble(precio.Text);
            s.Nombre = nombreS.Text;
            s.Identificador =Convert.ToInt32 (identificador.Text);
            s.Descripcion = descripcion.Text;

            int i = s.regresaID(nombreP.Text);
            

            int add = s.altaServicios();
            if (add == 1)
            {
                int ii = s.regresaID(nombreP.Text);
                int iii = s.regresaID();
                a.idProveedor = ii;
                a.idServicios = iii;
                int h = a.altaAtiende();
                if (h == 1)
                {
                    MessageBox.Show("Datos guardados correctamente!! \n \n\t Se ha registrado exitosamente !!");
                    Response.Redirect("/Inicio.aspx");
                }
                else
                    MessageBox.Show("Verifica tus datos !!!");
            }
            else if (add == 0)
                MessageBox.Show("Verificar sus datos!! ");
            else
                MessageBox.Show("Problemas con el servidor \n Espere unos momentos");
        }
    }
}