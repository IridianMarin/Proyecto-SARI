﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UTP_Ducks.Modelo;
using System.Windows.Forms;

namespace UTP_Ducks.Vista.Rf
{
    public partial class Consulta_Solicitud : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Detalles_Servicios ds=new Detalles_Servicios();
            if (DropDownList1.Text.Equals(""))
                MessageBox.Show("Seleccione una accion para consultar");
            else
                ds.Consulta(Gv,DropDownList1.Text);
        }
    }
}