﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UTP_Ducks.Modelo;
using System.Windows.Forms;

namespace UTP_Ducks.RF
{
    public partial class Solicitud : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Calendar1.Visible = false;

        }

        protected void inicio_TextChanged(object sender, EventArgs e)
        {

        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            Fcompra.Text = Calendar1.SelectedDate.ToShortDateString();
            Calendar1.Visible = false;

        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (Calendar1.Visible)
            {
                Calendar1.Visible = false;
            }
            else
            {
                Calendar1.Visible = true;
            }

        }

        protected void btnEnviar_Click(object sender, EventArgs e)
        {
            Modelo.Solicitud q = new Modelo.Solicitud();
            Modelo.Detalles_Servicios d = new Modelo.Detalles_Servicios();
            Modelo.Servicios s = new Modelo.Servicios();
            
            int i = q.regresaID3(nombreRequisitor.Text);
            q.idUsuario = i;
            q.Caracteristicas = nombreProducto.Text; ;

            string o = q.regresaNombre(nombreProducto.Text);
            q.Caracteristicas = o;
            
            q.Tipo = tipoSolicitud.Text;
            q.Fecha = DateTime.Parse(Fcompra.Text);
            q.Monto = Convert.ToInt32(monto.Text);
            int add = q.altaSolicitud();
            if (add == 1)
            {
                int ii = q.regresaID();
                int iii = s.regresaID();
                d.id_Compra = ii;
                d.idServicios = iii;
                MessageBox.Show("Solicitud de compra agregada con exito");
                btnEnviar.Visible = false;
                Response.Redirect("/Inicio.aspx");
            }
            else if (add == 0)
                MessageBox.Show("No se pudo agregar la compra vuelva a intentarlo \n Verifique sus datos");
            else
                MessageBox.Show("Problemas tecnicos... \n \t Favor de esperar");   

        }
    }
}