﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using UTP_Ducks.Modelo;

namespace UTP_Ducks.RM
{
    public partial class Proveedor : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnEnviar_Click(object sender, EventArgs e)
        {
            Modelo.Proveedor p = new Modelo.Proveedor();
            Modelo.TelefonoProveedor t = new Modelo.TelefonoProveedor();
            p.Email = email.Text;
            p.Nombre_RazonSocial = razon.Text;
            

            int add = p.altaProveedor();
            if (add == 1)
            {
                MessageBox.Show("Datos guardados correctamente!!");

            }

            t.Tipo = tipo.Text;
            int add2 = t.altaTelefonoProveedor();
            if(add2==1)
            {
                MessageBox.Show("Datos guardados correctamente!!");
                Response.Redirect("/Vista/Rm/DireccionP_roveedor.aspx");

            }
            else if (add == 0)
                MessageBox.Show("Verificar sus datos!! ");
            else
                MessageBox.Show("Problemas con el servidor \n Espere unos momentos");
            btnEnviar.Visible = false;
        }
    }
}