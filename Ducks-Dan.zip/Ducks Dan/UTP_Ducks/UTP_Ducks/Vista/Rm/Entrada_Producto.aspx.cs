﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using UTP_Ducks.Modelo;

namespace UTP_Ducks.RM
{
    public partial class Entrada_Producto : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Calendar1.Visible = false;

        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            entrada.Text = Calendar1.SelectedDate.ToShortDateString();
            Calendar1.Visible = false;

        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (Calendar1.Visible)
            {
                Calendar1.Visible = false;
            }
            else
            {
                Calendar1.Visible = true;
            }

        }

        protected void btnEnviar_Click(object sender, EventArgs e)
        {
            Modelo.Entradas a = new Modelo.Entradas();
            Modelo.DetalleEntrada de = new DetalleEntrada();
            Modelo.Productos p = new Modelo.Productos();
           
            int i = a.regresaID(nombreEmpleado.Text);
            a.idEmpleado = i;
            a.Descripcion = descripcion.Text;
            a.Total = Convert.ToDouble(total.Text);
            a.Fecha = DateTime.Parse(entrada.Text);
            a.Hora = horasalida.Text;
            
   
            int add = a.altaEntrada();
            if (add == 1)
            {
                int ii = a.regresaID();
                


                
                de.idProducto = p.regresaID();
                de.No_Articulos = Convert.ToInt32(total.Text);
                int iii = de.altaDetalleEntrada();

               





                if (ii == 1)
                {
                    MessageBox.Show("Datos guardados correctamente!!");
                }

            }
            else if (add == 0)
                MessageBox.Show("Verificar sus datos!! ");
            else
                MessageBox.Show("Problemas con el servidor \n Espere unos momentos");
            btnEnviar.Visible = false;
        }
    }
}