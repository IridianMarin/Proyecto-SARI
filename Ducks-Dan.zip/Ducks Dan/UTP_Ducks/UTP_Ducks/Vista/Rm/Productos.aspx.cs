﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using UTP_Ducks.Modelo;

namespace UTP_Ducks.RM
{
    public partial class Productos : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Calendar1.Visible = false;

        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (Calendar1.Visible)
            {
                Calendar1.Visible = false;
            }
            else
            {
                Calendar1.Visible = true;
            }

        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            fecha.Text = Calendar1.SelectedDate.ToShortDateString();
            Calendar1.Visible = false;
        }

        protected void btnEnviar_Click(object sender, EventArgs e)
        {
            Modelo.Productos p = new Modelo.Productos();
            p.Modelo = modelo.Text;
            p.Marca = marca.Text;
            p.Descripcion = descripcion.Text;
            p.Fecha = DateTime.Parse(fecha.Text);
            p.Grupo = grupo.Text;
            p.UnidadMedida = unidad.Text;
            p.CantidadMedida = Convert.ToDouble(cantidad.Text);
            p.PrecioCompra = Convert.ToDouble(precio.Text);
            p.Stock = Convert.ToInt32(stock.Text);
            
          
            int add = p.altaProducto();
            if (add == 1)
            {
                MessageBox.Show("Datos guardados correctamente!!");

            }
            else if (add == 0)
                MessageBox.Show("Verificar sus datos!! ");
            else
                MessageBox.Show("Problemas con el servidor \n Espere unos momentos");
        }
    }
}