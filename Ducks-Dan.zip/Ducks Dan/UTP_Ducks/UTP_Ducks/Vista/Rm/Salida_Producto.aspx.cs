﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;
using UTP_Ducks.Modelo;

namespace UTP_Ducks.RM
{
    public partial class Salida_Producto : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Calendar1.Visible = false;

        }

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            if (Calendar1.Visible)
            {
                Calendar1.Visible = false;
            }
            else
            {
                Calendar1.Visible = true;
            }
        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            salida.Text = Calendar1.SelectedDate.ToShortDateString();
            Calendar1.Visible = false;
        }

        protected void btnEnviar_Click(object sender, EventArgs e)
        {
            Modelo.Salida s = new Modelo.Salida();
            Modelo.DetalleSalida de = new Modelo.DetalleSalida();
            Modelo.Productos p = new Modelo.Productos();
            s.idEmpleado = Convert.ToInt32(nombreE.Text);
            s.Descripcion = desc.Text;
            s.Fecha =Convert.ToDateTime(salida.Text);
            s.Hora = hora.Text;

            int i = s.regresaID();
            int add = s.altaSalida();
            if (add == 1)
            {
                de.idSalida = i;
                de.idProducto = p.regresaID();
                de.No_Articulos = Convert.ToInt32(total.Text);
                int ii = de.alta();
                if (ii == 1)
                {
                    MessageBox.Show("Datos guardados correctamente!!");
                }

            }
            else if (add == 0)
                MessageBox.Show("Verificar sus datos!! ");
            else
                MessageBox.Show("Problemas con el servidor \n Espere unos momentos");

        }
    }
}