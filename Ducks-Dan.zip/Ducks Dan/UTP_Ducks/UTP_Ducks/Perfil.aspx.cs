﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using UTP_Ducks.Modelo;
using System.Windows.Forms;

namespace UTP_Ducks
{
    public partial class Perfil : System.Web.UI.Page
    {
        Modelo.Usuario u = new Modelo.Usuario();
        protected void Page_Load(object sender, EventArgs e)
        {
            String valor = "";
            int id = u.regresaID1(valor);
            idN.Text = id.ToString();
            name.Text = u.regresaIDN(id);
            apP.Text = u.regresaIDAP(id);
            apM.Text = u.regresaIDAM(id);
            sexo.Text = u.regresaG(id);
            curp.Text = u.regresaC(id);
            rfc.Text = u.regresaRFC(id);
            ec.Text = u.regresaEC(id);
            nacimiento.Text = u.regresaFN(id);
        }
        protected void BtnEnviar(object sender,EventArgs e)
        {
                NewContra.Enabled = true;
                NewContra2.Enabled = true;
                contraAnterior.Enabled = true;
                modificar.Enabled = true;
        }
        protected void btnCambio(object sender,EventArgs e)
        {
            Logueo l=new Logueo();
            String ii=u.regresaT(name.Text,apP.Text,apM.Text);
            if(NewContra.Text.Equals(NewContra2.Text))
            {
                 int i = u.cambiocontraseña(NewContra2.Text,contraAnterior.Text,ii);
                 if (i == 1)
                     MessageBox.Show("Contraseña Cambiada");
                 else if (i == 0)
                     MessageBox.Show("Verificar contraseña!! ");
                 else
                     MessageBox.Show("Problemas tecnicos!! ","Error",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
            else
                MessageBox.Show("La contraseña no corresponde con la otra \n \t Verificar los datos!! ", "Precaucion", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
        }
    }
}