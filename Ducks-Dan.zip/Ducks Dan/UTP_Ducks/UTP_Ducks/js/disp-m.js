$(document).ready(function(){
  $('.menu  > li:has(ul)').addClass('activado');
   $('.menu > li > a').click(function() {
     var comprobar = $(this).next();
     $('.menu li').removeClass('activado');
     $(this).closest('li').addClass('activado');
     if((comprobar.is('ul')) && (comprobar.is(':visible'))) {
        $(this).closest('li').removeClass('activado');
        comprobar.slideUp();
     }
     if((comprobar.is('ul')) && (!comprobar.is(':visible'))) {
        $('.menu ul ul:visible').slideUp();
        comprobar.slideDown();
     }
  });
  $('.menu > li > ul > li:has(ul)').addClass('activado');
   $('.menu > li > ul > li > a').click(function() {
     var comprobar = $(this).next();
     $('.menu ul ul li').removeClass('activado');
     $(this).closest('ul ul li').addClass('activado');
     if((comprobar.is('ul ul')) && (comprobar.is(':visible'))) {
        $(this).closest('ul ul li').removeClass('activado');
        comprobar.slideUp('normal');
     }
     if((comprobar.is('ul ul')) && (!comprobar.is(':visible'))) {
        $('.menu ul ul ul:visible').slideUp();
        comprobar.slideDown();
     }
  });
   
});

