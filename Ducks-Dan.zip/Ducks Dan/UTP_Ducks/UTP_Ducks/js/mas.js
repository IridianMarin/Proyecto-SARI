$(document).ready(main);
var contador=1;
function main () {
	$('.contenedor-menu .btn-menu').click(function(){
		if(contador==1){
			$('.contenedor-menu .menu').animate({
				left:'0'
			});
			contador=0;
		}else{
			contador=1;
			$('.contenedor-menu .menu').animate({
				left:'-100%'
			});
		}
	});
}