$(document).ready(function(){
    $(window).resize(function(){
    if($(document).width() > 1027){
        $('.contenedor-menu .menu').slideDown();
        $('.contenedor-menu .menu').css({'display':'flex'});
        $('.contenedor-menu .menu').css({'justify-content':'center'});
        $('.contenedor-menu .menu li ul').slideUp();
    }
    if($(document).width() < 1027){
        $('.contenedor-menu .menu').slideUp();
        $('.contenedor-menu .menu').css({'display':'none'});;
        $('.contenedor-menu .menu li ul').slideUp();
    }
   });
    $('.contenedor-menu .menu li:has(ul)').click(function(e){
        e.preventDefault();
    });
   $('.contenedor-menu .btn-menu').click(function(){
    $('.contenedor-menu .menu').slideToggle();
   }); 
   
   $('.contenedor-menu .menu li ul li ul li a').click(function(){
        window.location.href = $(this).attr("href");
   });
   $('.contenedor-menu .menu li ul li a').click(function(){
        window.location.href = $(this).attr("href");
   });
});
